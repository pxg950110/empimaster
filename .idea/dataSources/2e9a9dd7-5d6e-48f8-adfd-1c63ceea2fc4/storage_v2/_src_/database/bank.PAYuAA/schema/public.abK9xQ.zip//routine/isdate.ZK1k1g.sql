create function isdate(datestr character varying) returns boolean
    language plpgsql
as
$$
BEGIN

IF (dateStr IS NULL) THEN 

     RETURN FALSE; 

END IF; 

     PERFORM dateStr::timestamp; 

     RETURN TRUE; 

EXCEPTION 

     WHEN others THEN 

     RETURN FALSE; 

 

 

END;

$$;

alter function isdate(varchar) owner to postgres;

