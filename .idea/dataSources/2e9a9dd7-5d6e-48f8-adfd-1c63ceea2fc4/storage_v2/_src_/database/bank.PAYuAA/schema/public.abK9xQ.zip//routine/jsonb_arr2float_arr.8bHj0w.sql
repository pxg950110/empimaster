create function jsonb_arr2float_arr(_js jsonb) returns double precision[]
    language sql
as
$$
SELECT ARRAY(SELECT jsonb_array_elements_text(_js)::FLOAT)
--SELECT ARRAY(SELECT jsonb_array_elements_text(_js))
$$;

alter function jsonb_arr2float_arr(jsonb) owner to postgres;

