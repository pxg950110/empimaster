create view v_best_record_identifier(id, person_id, euid, quality, name, pinyin, alias, birth_day, id_number,
                                     birth_place, native_place, operate_type, created_by, created_time, identifier,
                                     identifier_domain_id, identifier_domain, gender, marry_status, ethnicity,
                                     nationality, carrer, is_valid, last_update_by, last_update_time, is_primary) as
SELECT (((((b.euid)::text || '-'::text) || a.id) || '-'::text) || (a.identifier)::text) AS id,
       b.id                                                                             AS person_id,
       b.euid,
       b.quality,
       b.name,
       b.pinyin,
       b.alias,
       b.birth_day,
       b.id_number,
       b.birth_place,
       b.native_place,
       b.operate_type,
       b.created_by,
       b.created_time,
       a.identifier,
       a.identifier_domain_id,
       (SELECT b_1.name
        FROM empi.identifier_domain b_1
        WHERE (b_1.id = a.identifier_domain_id))                                        AS identifier_domain,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.gender_id))                                     AS gender,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.marry_status_id))                               AS marry_status,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.ethnicity_id))                                  AS ethnicity,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.nationality_id))                                AS nationality,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.carrer_id))                                     AS carrer,
       a.is_valid,
       a.last_update_by,
       a.last_update_time,
       a.is_primary
FROM (empi.person_identifier a
         JOIN empi.person b ON (((a.person_id = b.id) AND (a.is_primary = 1))));

alter table v_best_record_identifier
    owner to postgres;

