create function array_median(double precision[]) returns double precision
    immutable
    language sql
as
$$
SELECT CASE WHEN array_upper($1,1) = 0 THEN null
                ELSE asorted[ceiling(array_upper(asorted,1)/2.0)]::double precision END
       FROM (SELECT ARRAY(SELECT $1[n]
                FROM generate_series(1, array_upper($1, 1)) AS n
               WHERE $1[n] IS NOT NULL
               ORDER BY $1[n]) As asorted) As foo
$$;

alter function array_median(double precision[]) owner to postgres;

