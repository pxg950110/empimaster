create function maskid(name text) returns text
    language sql
as
$$
SELECT  overlay(name placing '********' from 3 FOR 10 )

$$;

alter function maskid(text) owner to postgres;

