create function replacecdmid(cdmid text) returns integer
    language sql
as
$$
SELECT  regexp_replace(cdmid,'^[a-z0]*','')::INT

$$;

alter function replacecdmid(text) owner to postgres;

