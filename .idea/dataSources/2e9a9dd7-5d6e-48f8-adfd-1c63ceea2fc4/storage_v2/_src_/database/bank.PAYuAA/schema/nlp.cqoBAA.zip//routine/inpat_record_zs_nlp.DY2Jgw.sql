create function inpat_record_zs_nlp(patientid character varying, inpatid character varying, recordid character varying, recordtype character varying, content1 character varying, content2 character varying, content3 character varying, content4 character varying, content5 character varying) returns void
    language plpgsql
as
$$
DECLARE record_num int;
BEGIN
    SELECT count(1) into record_num FROM nlp.nlp_inhospital_record where record_id=recordid::integer;
    if record_num>0 then
        update nlp.nlp_inhospital_record set patient_id=patientid::integer,visit_id=inpatid::integer,visit_type='I',name=content1,chief_complaint_json=content2::json,chief_complaint_yes_json=content3::json
,chief_complaint_no_json=content4::json,chief_complaint_num_json=content5::json,nlp_time=current_timestamp where "type"=recordtype and  record_id=recordid::int;
        -- update emr.inpat_medical_record set nlp_flag='1' where record_id=recordid::integer;
    END IF;
     if record_num=0 THEN
    insert into nlp.nlp_inhospital_record(patient_id,type,record_id,visit_type,visit_id,name,chief_complaint_json,chief_complaint_yes_json,chief_complaint_no_json,chief_complaint_num_json,nlp_time) VALUES (patientid::integer,recordtype,recordid::integer,'I',inpatid::integer,content1,content2::json,content3::json,content4::json,content5::json,current_timestamp);
    -- update emr.inpat_medical_record set nlp_flag='1' where record_id=recordid::integer;
    END IF;
END;
$$;

alter function inpat_record_zs_nlp(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

