create view v_best_record(id, euid, quality, name, pinyin, alias, birth_day, id_number, birth_place, native_place,
                          gender, marry_status, ethnicity, nationality, carrer, operate_type, created_by, created_time,
                          last_update_by, last_update_time) as
SELECT a.euid                                             AS id,
       a.euid,
       a.quality,
       a.name,
       a.pinyin,
       a.alias,
       a.birth_day,
       a.id_number,
       a.birth_place,
       a.native_place,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.gender_id))       AS gender,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.marry_status_id)) AS marry_status,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.ethnicity_id))    AS ethnicity,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.nationality_id))  AS nationality,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.carrer_id))       AS carrer,
       a.operate_type,
       a.created_by,
       a.created_time,
       a.last_update_by,
       a.last_update_time
FROM empi.best_record a;

alter table v_best_record
    owner to postgres;

