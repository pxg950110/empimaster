create function text_to_xml(data text) returns xml
    language plpgsql
as
$$
DECLARE
    result xml;
  BEGIN
         SELECT data::xml into result;
          RETURN result;
        EXCEPTION WHEN OTHERS THEN
            result=null;
       RETURN result;
  END;
$$;

alter function text_to_xml(text) owner to postgres;

