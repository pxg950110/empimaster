create function auto_upd_nlp_ul_report(reportid character varying, patientid character varying, visittype character varying, visitid character varying, sourcetext character varying, report1 character varying, report2 character varying, report3 character varying, report4 character varying) returns void
    language plpgsql
as
$$
DECLARE report_num int;
  BEGIN
    SELECT count(1) into report_num FROM nlp.nlp_ultrasound_report where report_id=reportid::INTEGER;
    IF report_num=0 THEN
      INSERT INTO nlp.nlp_ultrasound_report(report_id,patient_id,visit_type,visit_id,source_text,report_json,report_num_json,report_yes_json,report_no_json,nlp_time) VALUES (reportid::INTEGER,patientid::INTEGER,visittype,visitid::INTEGER,sourcetext,report1::json,report2::json,report3::json,report4::json,current_timestamp);
      update checks.ultrasound_report set nlp_flag=1 where report_id=reportid::INTEGER;
    END IF;
    IF report_num>0 THEN
      DELETE FROM nlp.nlp_ultrasound_report t where t.report_id=reportid::INTEGER;
      INSERT INTO nlp.nlp_ultrasound_report(report_id,patient_id,visit_type,visit_id,source_text, report_json,report_num_json,report_yes_json,report_no_json,nlp_time) VALUES (reportid::INTEGER,patientid::INTEGER,visittype,visitid::INTEGER,sourcetext,report1::json,report2::json,report3::json,report4::json,current_timestamp);
      update checks.ultrasound_report set nlp_flag=1 where report_id=reportid::INTEGER;
	  
	  
	  

    END IF;
  
  END;
$$;

alter function auto_upd_nlp_ul_report(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

