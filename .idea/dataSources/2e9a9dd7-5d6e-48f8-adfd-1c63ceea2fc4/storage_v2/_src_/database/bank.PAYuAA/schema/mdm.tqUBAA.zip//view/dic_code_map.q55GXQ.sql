create view dic_code_map(map_code, map_name, map_id, source_id, source_code, source_name, code_sys_id) as
SELECT t1.map_code,
       t1.map_name,
       t1.map_id,
       t1.source_id,
       t1.source_code,
       t1.source_name,
       t2.code_sys_id
FROM (mdm.code_map t1
         LEFT JOIN mdm.code_set t2 ON ((t1.source_id = t2.code_id)));

alter table dic_code_map
    owner to postgres;

