create function get_mdm_information_standard(code_source text, code_sys_id_source text, number character varying) returns character varying
    language plpgsql
as
$$
/**************
 此函数的功能：实现获取标准的code与name
 创建人：宋力力
 入参详解：code_source（原始code）,code_sys_id_source（原始的字典）,number（用来标识取id,code,name）
 返回值：得到相关的name(number=3)，code（number=2）
 创建日期：2018/06/13
 修改人：侯应伟
 修改时间：2018/06/19 15：25:30
 修改原因：sds中text格式的处理
 **************/
DECLARE
  result_name varchar;
  result_code varchar ;
BEGIN
  IF number='2' then
select map_code into result_code from mdm.dic_code_map where source_code=code_source::varchar and code_sys_id=code_sys_id_source::INTEGER;
ELSEIF  number='3' then
  select map_name into result_name from mdm.dic_code_map where source_code=code_source::varchar and code_sys_id=code_sys_id_source::INTEGER;
  END IF ;
IF number='2' THEN
  RETURN result_code;
ELSEIF number='3' THEN
    RETURN result_name;
END IF;
END;
$$;

alter function get_mdm_information_standard(text, text, varchar) owner to postgres;

