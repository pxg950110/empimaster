create function hyw_get_mdm_information(itemclass character varying, code1 character varying, code_sys_id1 integer, flag character varying, OUT result_id character varying, OUT result_name character varying, OUT result_code character varying) returns record
    language plpgsql
as
$$
/**************
目前未实现lis_item表的获取
 此函数的功能：实现获取id,code,name
 创建人：宋力力
 修改人：皮小怪
 入参详解：itemclass（item表项目类别）,code1（原始的code）,code_sys_id1（字典标识），flag（用来判别取得是code_set中的信息还是其他相关字典表中的信息）,number（用来标识取id,code,name）
 返回值：得到相关的name(number=3)，code(number=2)，id（number=1）
 创建日期：2018/06/13
 **************/
BEGIN
if flag not in('diagnose','bed','department','employee','drug','item','operation','lis_item') then
    result_id:=(select code_id::varchar  from mdm.code_set where code_sys_id=code_sys_id1 and code=code1);
     result_code:= (select code  from mdm.code_set where code_sys_id=code_sys_id1 and code=code1);
     result_name:=(select name from mdm.code_set where code_sys_id=code_sys_id1 and code=code1);
ELSEIF flag in('diagnose') then --诊断
    result_id:=(select diag_id::varchar from mdm.diagnose where code_sys_id=code_sys_id1 and diag_code=code1);
     result_code:=(select  diag_code from mdm.diagnose where code_sys_id=code_sys_id1 and diag_code=code1);
    result_name:=(select diag_name  from mdm.diagnose where code_sys_id=code_sys_id1 and diag_code=code1);
ELSEIF flag in('department') then --科室
    result_id:=(select dept_id::varchar from mdm.department where code_sys_id=code_sys_id1 and dept_code=code1);
    result_code:=(select dept_code  from mdm.department where code_sys_id=code_sys_id1 and dept_code=code1);
   result_name:=( select dept_name  from mdm.department where code_sys_id=code_sys_id1 and dept_code=code1);
ELSEIF flag in('employee') then --人员
    result_id:=(select empl_id::varchar from mdm.employee where code_sys_id=code_sys_id1 and empl_code=code1);
    result_code:=(select empl_code  from mdm.employee where code_sys_id=code_sys_id1 and empl_code=code1);
    result_name:=(select empl_name from mdm.employee where code_sys_id=code_sys_id1 and empl_code=code1);
ELSEIF flag in('drug') then --药品
    result_id:=(select drug_id::varchar  from mdm.drug where code_sys_id=code_sys_id1 and drug_code=code1);
    result_code:=(select drug_code from mdm.drug where code_sys_id=code_sys_id1 and drug_code=code1);
    result_name:=(select trade_name  from mdm.drug where code_sys_id=code_sys_id1 and drug_code=code1);
ELSEIF flag in('item') then --项目
    result_id:=(select item_id::varchar  from mdm.item where code_sys_id=code_sys_id1 and item_code=code1 and item_class=itemclass);
    result_code:=( select item_code  from mdm.item where code_sys_id=code_sys_id1 and item_code=code1 and item_class=itemclass);
    result_name:=(select item_name  from mdm.item where code_sys_id=code_sys_id1 and item_code=code1 and item_class=itemclass);
ELSEIF flag in('operation') then --手术
    result_id:=(select operation_id::varchar  from mdm.operation where code_sys_id=code_sys_id1 and operation_code=code1);
    result_code:=( select operation_code from mdm.operation where code_sys_id=code_sys_id1 and operation_code=code1);
    result_name:=(select operation_name  from mdm.operation where code_sys_id=code_sys_id1 and operation_code=code1);
END IF;
END;
$$;

alter function hyw_get_mdm_information(varchar, varchar, integer, varchar, out varchar, out varchar, out varchar) owner to postgres;

