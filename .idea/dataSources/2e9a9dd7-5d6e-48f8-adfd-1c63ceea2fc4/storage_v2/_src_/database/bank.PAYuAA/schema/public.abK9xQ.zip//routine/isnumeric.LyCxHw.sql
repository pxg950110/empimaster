create function isnumeric(txtstr character varying) returns boolean
    language plpgsql
as
$$
BEGIN
RETURN txtStr ~ '^([0-9]+[.]?[0-9]*|[.][0-9]+)$';
END;
$$;

alter function isnumeric(varchar) owner to postgres;

