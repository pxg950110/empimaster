create function two_tokengen(inputs text[]) returns bytea[]
    language plpgsql
as
$$
DECLARE
                          input  TEXT;
                          len    INT;
                          res    TEXT [] := '{}' :: TEXT [];
                          tokens BYTEA [];
                        BEGIN
                          FOREACH input IN ARRAY $1 LOOP
                            len = length(input);
                            IF len <= 1
                            THEN
                              res := array_append(res, input);
                            ELSE
                              FOR i IN 1..len - 1 LOOP
                                res := array_append(res, substring(input, i, 2));
                              END LOOP;
                            END IF;
                          END LOOP;
                          SELECT ARRAY(SELECT md5(encode(convert_to(r, 'utf-8'), 'hex') :: TEXT ||
                                                  md5(encode(convert_to(right(r, 1), 'utf-8'), 'base64') :: TEXT) :: TEXT) :: BYTEA
                                       FROM unnest(res) r)
                          INTO tokens;
                          RETURN tokens;
                        END;
$$;

alter function two_tokengen(text[]) owner to postgres;

