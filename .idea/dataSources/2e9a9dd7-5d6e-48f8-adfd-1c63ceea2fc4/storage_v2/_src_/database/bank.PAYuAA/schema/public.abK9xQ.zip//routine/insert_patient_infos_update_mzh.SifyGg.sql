create function insert_patient_infos_update_mzh(_org_code character varying, _patient_name character varying, _spell_code character varying, _wb_code character varying, _sex_code character varying, _sex_name character varying, _birth_date character varying, _birth_address character varying, _id_type_code character varying, _id_type_name character varying, _id_no character varying, _country_code character varying, _country_name character varying, _nation_code character varying, _nation_name character varying, _marriage_code character varying, _marriage_name character varying, _profession character varying, _abo_code character varying, _abo_name character varying, _rh_code character varying, _rh_name character varying, _native_place character varying, _account_address character varying, _phone character varying, _mail character varying, _contact_name character varying, _contact_relation_code character varying, _contact_relation_name character varying, _contact_phone character varying, _contact_address character varying, _contact_zip character varying, _home_address character varying, _home_phone character varying, _home_zip character varying, _work_address character varying, _work_phone character varying, _work_zip character varying, _note character varying, _system_code character varying, _create_oper_id character varying, _update_oper_id character varying, _is_valid character varying, _source_id_type character varying, _source_patient_no character varying, _card_type character varying, _card_no character varying, _card_type_one character varying) returns character varying
    language plpgsql
as
$$
    -- Author:		songlili
-- Create date: 2018-07-31 11:27
-- Description:	门诊号存在则更新主信息与基本信息的数据
DECLARE
         _empi varchar;
BEGIN

      --若患者存在
      select empi into _empi from patient.patient_master_info where patient_id in (select patient_base_info.patient_id from patient.patient_base_info where source_patient_no=_source_patient_no);
        --更新patient_master_info表中患者主记录数据
       UPDATE patient.patient_master_info SET patient_name=_patient_name,spell_code=_spell_code,wb_code=_wb_code,sex_code=_sex_code,sex_name=_sex_name,birth_date=_birth_date::DATE ,birth_address=_birth_address,
         id_type_code=_id_type_code,id_type_name=_id_type_name,id_no=_id_no,country_code=_country_code,country_name=_country_name,nation_code=_nation_code,nation_name=_nation_name,
         marriage_code=_marriage_code,marriage_name=_marriage_name,profession=_profession,abo_code=_abo_code,abo_name=_abo_name,rh_code=_rh_code,rh_name=_rh_name,
         native_place=_native_place,account_address=_account_address,phone=_phone,mail=_mail,contact_name=_contact_name,contact_relation_code=_contact_relation_code,
         contact_relation_name=_contact_relation_name,contact_phone=_contact_phone,contact_address=_contact_address,contact_zip=_contact_zip,home_address=_home_address,
         home_phone=_home_phone,home_zip=_home_zip,work_address=_work_address,work_phone=_work_phone,work_zip=_work_zip,note=_note,system_code=_system_code,update_oper_id=_update_oper_id::INTEGER,
         update_time=current_timestamp,is_valid=_is_valid::BOOLEAN,etl_time=current_timestamp
         WHERE empi=_empi;
          --更新patient_base_info表中患者主记录数据
          UPDATE patient.patient_base_info SET card_type=_card_type_one,card_no=_card_no,patient_name=_patient_name,spell_code=_spell_code,wb_code=_wb_code,sex_code=_sex_code,sex_name=_sex_name,birth_date=_birth_date::DATE ,
            birth_address=_birth_address,id_type_code=_id_type_code,id_no=_id_no,country_code=_country_code,country_name=_country_name,nation_code=_nation_code,nation_name=_nation_name,marriage_code=_marriage_code,
            marriage_name=_marriage_name,profession=_profession,abo_code=_abo_code,abo_name=_abo_name,rh_code=_rh_code,rh_name=_rh_name,native_place=_native_place,account_address=_account_address,phone=_phone,mail=_mail,
            contact_name=_contact_name,contact_relation_code=_contact_relation_code,contact_relation_name=_contact_relation_name,contact_phone=_contact_phone,contact_address=_contact_address,contact_zip=_contact_zip,
            home_address=_home_address,home_phone=_home_phone,home_zip=_home_zip,work_address=_work_address,work_phone=_work_phone,work_zip=_work_zip,update_oper_id=_create_oper_id::INTEGER,update_time=current_timestamp,
            is_valid=TRUE,etl_time=current_timestamp WHERE source_patient_no=_source_patient_no;
           return '1';
END;
$$;

alter function insert_patient_infos_update_mzh(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

