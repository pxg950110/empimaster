create function menu_data_status(pat_id integer, OUT menu_code text, OUT menu_name text, OUT identify integer) returns SETOF record
    language sql
as
$$
SELECT
  'summary',
  '概要',
  0 AS identify
UNION ALL
SELECT
  'patient_diagnose',
  '诊断',
  patient_diagnose.pat_diag_id AS identify
FROM (SELECT pat_diag_id
      FROM diag.patient_diagnose
      WHERE patient_id = pat_id
      LIMIT 1) AS patient_diagnose
UNION ALL
SELECT
  'visit_record',
  '病历',
  visit_record.visit_id AS identify
FROM (SELECT visit_id
      FROM visit.visit_record
      WHERE patient_id = pat_id
      LIMIT 1) AS visit_record
UNION ALL
SELECT
  'inout_merge_view',
  '用药医嘱',
  inout_merge_view.order_id AS identify
FROM (SELECT order_id
      FROM orders.inout_merge_view
      WHERE patient_id = pat_id
      LIMIT 1) AS inout_merge_view
UNION ALL
SELECT
  'inpat_undrug_order',
  '其他医嘱',
  inpat_undrug_order.order_id AS identify
FROM (SELECT order_id
      FROM orders.inpat_undrug_order
      WHERE patient_id = pat_id
      LIMIT 1) AS inpat_undrug_order
UNION ALL
SELECT
  'lab_result',
  '检验',
  CASE WHEN (SELECT content
             FROM platform.system_config
             WHERE key = 'Microbe_Report_Belongs'
             LIMIT 1) = 'lab'
    THEN (SELECT report_id
          FROM lab.lab_report_view_with_microbe
          WHERE patient_id = pat_id
          LIMIT 1)
  ELSE (SELECT report_id
        FROM lab.lab_report
        WHERE patient_id = pat_id
        LIMIT 1) END AS identify
UNION ALL
SELECT
  'check_report',
  '检查',
  CASE WHEN (SELECT content
             FROM platform.system_config
             WHERE key = 'Microbe_Report_Belongs'
             LIMIT 1) = 'check'
    THEN (SELECT report_id
          FROM checks.check_report_view_with_microbe
          WHERE patient_id = pat_id
          LIMIT 1)
  ELSE (SELECT report_id
        FROM checks.check_report_view
        WHERE patient_id = pat_id
        LIMIT 1) END AS identify
UNION ALL
SELECT
  'pathology_report',
  '病理',
  pathology_report.report_id AS identify
FROM (SELECT report_id
      FROM checks.pathology_report
      WHERE patient_id = pat_id
      LIMIT 1) AS pathology_report
UNION ALL
SELECT
  'operation_record',
  '手术',
  operation_record.oper_id AS identify
FROM (SELECT oper_id
      FROM operation.operation_record
      WHERE patient_id = pat_id
      LIMIT 1) AS operation_record
UNION ALL
SELECT
  'blood_transfusion_record',
  '输血',
  blood_transfusion_record.id AS identify
FROM (SELECT id
      FROM other.blood_transfusion_record
      WHERE patient_id = pat_id
      LIMIT 1) AS blood_transfusion_record
UNION ALL
SELECT
  'chemotherapy_record',
  '化疗',
  chemotherapy_record.chemotherapy_id AS identify
FROM (SELECT chemotherapy_id
      FROM tumour.chemotherapy_record
      WHERE patient_id = pat_id
      LIMIT 1) AS chemotherapy_record
UNION ALL
SELECT
  'radiotherapy_record',
  '放疗',
  radiotherapy_record.radiotherapy_id AS identify
FROM (SELECT radiotherapy_id
      FROM tumour.radiotherapy_record
      WHERE patient_id = pat_id
      LIMIT 1) AS radiotherapy_record
UNION ALL
SELECT
  'patient_allergy',
  '过敏',
  patient_allergy.allergy_id AS identify
FROM (SELECT allergy_id
      FROM allergy.patient_allergy
      WHERE patient_id = pat_id
      LIMIT 1) AS patient_allergy
UNION ALL
SELECT
  'case_base',
  '病案',
  case_base.case_id AS identify
FROM (SELECT case_id
      FROM cases.case_base
      WHERE patient_id = pat_id
      LIMIT 1) AS case_base
UNION ALL
SELECT
  'physical_examination_record',
  '体检',
  physical_examination_record.phyexam_id AS identify
FROM (SELECT phyexam_id
      FROM phyexam.physical_examination_record
      WHERE patient_id = pat_id
      LIMIT 1) AS physical_examination_record
UNION ALL
SELECT
  'infection_record',
  '院感',
  infection_record.id AS identify
FROM (SELECT id
      FROM other.infection_record
      WHERE patient_id = pat_id
      LIMIT 1) AS infection_record
UNION ALL
SELECT
  'upload_file',
  '患者上传附件',
  wechat_emr.emr_id AS identify
FROM (SELECT emr_id
      FROM edc.fp_wechat_emr
      WHERE patient_id = pat_id
      LIMIT 1) AS wechat_emr
$$;

alter function menu_data_status(integer, out text, out text, out integer) owner to postgres;

