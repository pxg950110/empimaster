create function concat1(c1 character varying, c2 character varying) returns character varying
    language plpgsql
as
$$
begin
    return c1||'|'||c2;
  end;
$$;

alter function concat1(varchar, varchar) owner to postgres;

