create function out_insert_or_update_visit_record() returns trigger
    language plpgsql
as
$$
/***********************************************************************************************
*函数名 :out_insert_or_update_visit_record
*函数功能描述 ： 门诊就诊记录触发进入就诊总表  
*函数参数 ：
*函数返回值 ：trigger 触发器函数
*作者 ：pxg
*函数创建日期 ：2019-04-03
*函数修改日期 ：
*修改人 ：
*修改原因 ：
*版本 ：v1.0
*历史版本 ：
***********************************************************************************************/

declare
begin
   case
     when TG_OP='INSERT' and new.is_emergency = FALSE then
	 /**
	 
	 */
insert into visit.visit_record(id,patient_id,pat_base_id,org_code,visit_type,visit_id,source_app,source_visit_id,source_outpat_no,patient_name,age,age_unit,age_day,pay_kind_id,pay_kind_code,pay_kind_name,insurance_kind_id,insurance_kind_code,insurance_kind_name,dept_id,dept_code,dept_name,doc_id,doc_code,doc_name,is_emergency,visit_time,major_diag_id,major_diag_code,major_diag_name,visit_state_id,visit_state_code,visit_state_name,is_valid,oper_id,oper_code,oper_name,oper_time,etl_time) values
                                  (new.reg_id,new.patient_id,new.pat_base_id,new.org_code,'O',new.reg_id,new.source_app,new.source_reg_id,new.source_outpat_no,--
								  new.patient_name,new.age,new.age_unit,new.age_day,new.pay_kind_id,new.pay_kind_code,new.pay_kind_name,new.insurance_kind_id,new.insurance_kind_code,new.insurance_kind_name,new.dept_id,new.dept_code,new.dept_name,new.doc_id,new.doc_code,new.doc_name,new.is_emergency,new.reg_time,new.major_diag_id,new.major_diag_code,new.major_diag_name,new.visit_state_id,new.visit_state_code,new.visit_state_name,new.is_valid,new.oper_id,new.oper_code,new.oper_name,new.oper_time,new.etl_time);
      when TG_OP='INSERT' and new.is_emergency = TRUE then
         insert into visit.visit_record(id,patient_id,pat_base_id,org_code,visit_type,visit_id,source_app,source_visit_id,source_outpat_no,patient_name,age,age_unit,age_day,pay_kind_id,pay_kind_code,pay_kind_name,insurance_kind_id,insurance_kind_code,insurance_kind_name,dept_id,dept_code,dept_name,doc_id,doc_code,doc_name,is_emergency,visit_time,major_diag_id,major_diag_code,major_diag_name,visit_state_id,visit_state_code,visit_state_name,is_valid,oper_id,oper_code,oper_name,oper_time,etl_time) values
                                  (new.reg_id,new.patient_id,new.pat_base_id,new.org_code,'E',new.reg_id,new.source_app,new.source_reg_id,new.source_outpat_no,--
								  new.patient_name,new.age,new.age_unit,new.age_day,new.pay_kind_id,new.pay_kind_code,new.pay_kind_name,new.insurance_kind_id,new.insurance_kind_code,new.insurance_kind_name,new.dept_id,new.dept_code,new.dept_name,new.doc_id,new.doc_code,new.doc_name,new.is_emergency,new.reg_time,new.major_diag_id,new.major_diag_code,new.major_diag_name,new.visit_state_id,new.visit_state_code,new.visit_state_name,new.is_valid,new.oper_id,new.oper_code,new.oper_name,new.oper_time,new.etl_time);
      when TG_OP='UPDATE'  and new.is_emergency=FALSE then
        update visit.visit_record set id=new.reg_id, patient_id=new.patient_id,pat_base_id=new.pat_base_id,org_code=new.org_code,visit_type='O',source_app=new.source_app,source_visit_id=new.source_reg_id,source_outpat_no=new.source_outpat_no,patient_name=new.patient_name,age=new.age,age_unit=new.age_unit,age_day=new.age_day,pay_kind_id=new.pay_kind_id,pay_kind_code=new.pay_kind_code,pay_kind_name=new.pay_kind_name,
              insurance_kind_id=new.insurance_kind_id,insurance_kind_code=new.insurance_kind_code,insurance_kind_name=new.insurance_kind_name,dept_id=new.dept_id,dept_code=new.dept_code,dept_name=new.dept_name,doc_id=new.doc_id,doc_code=new.doc_code,doc_name=new.doc_name,is_emergency=new.is_emergency,visit_time=new.reg_time,major_diag_id=new.major_diag_id,major_diag_code=new.major_diag_code,major_diag_name=new.major_diag_name,visit_state_id=new.visit_state_id, visit_state_code=new.visit_state_code,visit_state_name=new.visit_state_name,is_valid=new.is_valid,oper_id=new.oper_id,oper_code=new.oper_code,oper_name=new.oper_name,oper_time=new.oper_time,etl_time=new.etl_time where visit_id=new.reg_id and visit_type in('O','E');
       when TG_OP='UPDATE'  and new.is_emergency=TRUE then
       update visit.visit_record set id=new.reg_id, patient_id=new.patient_id,pat_base_id=new.pat_base_id,org_code=new.org_code,visit_type='E',source_app=new.source_app,source_visit_id=new.source_reg_id,source_outpat_no=new.source_outpat_no,patient_name=new.patient_name,age=new.age,age_unit=new.age_unit,age_day=new.age_day,pay_kind_id=new.pay_kind_id,pay_kind_code=new.pay_kind_code,pay_kind_name=new.pay_kind_name,
              insurance_kind_id=new.insurance_kind_id,insurance_kind_code=new.insurance_kind_code,insurance_kind_name=new.insurance_kind_name,dept_id=new.dept_id,dept_code=new.dept_code,dept_name=new.dept_name,doc_id=new.doc_id,doc_code=new.doc_code,doc_name=new.doc_name,is_emergency=new.is_emergency,visit_time=new.reg_time,major_diag_id=new.major_diag_id,major_diag_code=new.major_diag_code,major_diag_name=new.major_diag_name,visit_state_id=new.visit_state_id, visit_state_code=new.visit_state_code,visit_state_name=new.visit_state_name,is_valid=new.is_valid,oper_id=new.oper_id,oper_code=new.oper_code,oper_name=new.oper_name,oper_time=new.oper_time,etl_time=new.etl_time where visit_id=new.reg_id and visit_type in('O','E');
       when TG_OP='DELETE' then
       delete from  visit.visit_record where org_code=old.org_code and visit_type in ('E','O') and source_app=old.source_app and  visit_id=old.reg_id;
    else
    return null;
    end case;
return NULL;
end;

$$;

alter function out_insert_or_update_visit_record() owner to postgres;

