create function calculationprecision(par text) returns integer
    language plpgsql
as
$$
declare
  total integer;
BEGIN
  IF POSITION('.' in cast(par as text)) = 0
  THEN
    total = 0;
    RETURN total;
  ELSE
    total = length(cast(par as text)) - POSITION('.' in cast(par as text)) + 1;
    RETURN total;
  END IF;
END;
$$;

alter function calculationprecision(text) owner to postgres;

