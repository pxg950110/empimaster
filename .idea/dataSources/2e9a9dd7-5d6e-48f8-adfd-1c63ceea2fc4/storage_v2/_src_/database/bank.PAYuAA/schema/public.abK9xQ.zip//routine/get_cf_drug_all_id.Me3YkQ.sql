create function get_cf_drug_all_id(drgid text) returns jsonb
    language sql
as
$$
WITH RECURSIVE T AS (
      SELECT distinct
        drug_property.drug_property_name,
        drug_property.drug_property_no,
        drug_property.parent_drug_property
      FROM mdm.mdm_drug_map drug_map
        inner join mdm.mdm_drug_property drug_property on drug_map.class @> ARRAY [drug_property.drug_property_no]
      where drug_map.source_id = drgid::int and drug_property.drug_feature = 'Drugnode'
      union ALL
      SELECT
        a.drug_property_name,
        a.drug_property_no,
        a.parent_drug_property
      FROM mdm.mdm_drug_property as a, T
      WHERE t.parent_drug_property <@ ARRAY [a.drug_property_no] and a.drug_feature = 'Drugnode'
    )
SELECT array_to_json(array_agg(drug_property_no))::jsonb|| to_jsonb(100000000 + drgid::int)
                           FROM (SELECT
                                   drug_property_name,
                                   drug_property_no,
                                   parent_drug_property
                                 FROM T
                                ) as tempp;
$$;

alter function get_cf_drug_all_id(text) owner to postgres;

