create function to_numeric(txtstr character varying, OUT result character varying) returns character varying
    language plpgsql
as
$$
BEGIN

IF txtStr ~ '^([0-9]+[.]?[0-9]*|[.][0-9]+)$'=TRUE  THEN
       result:=txtStr;
    else  result:= NULL ;
	  END IF;
		 RETURN;
	 END;
$$;

alter function to_numeric(varchar, out varchar) owner to postgres;

