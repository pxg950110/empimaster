create function maskname(name text) returns text
    language sql
as
$$
SELECT  overlay(name placing '*' from 2 )

$$;

alter function maskname(text) owner to postgres;

