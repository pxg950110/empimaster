create function get_drug_all_standardch(drgid text) returns text
    language sql
as
$$
with RECURSIVE r as (
  SELECT  a.id  ,a.standardch as standardch from concept_drg a where a.id=replacecdmid(drgid)
  UNION
    SELECT  k.id ,(c.standardch||'>'||k.standardch) as standardch  from concept_drg k inner join r c on  c.id=substring(k.parent::CHAR(50),2,length(k.parent::CHAR(50))-2)::INTEGER
)
SELECT standardch  from r;
$$;

alter function get_drug_all_standardch(text) owner to postgres;

