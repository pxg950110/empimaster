create function get_drug_all_id(drgid text) returns jsonb
    language sql
as
$$
with RECURSIVE r as (
  SELECT  unnest(parent) as pid from concept_drg where id=replacecdmid(drgid) UNION  SELECT  replacecdmid(drgid)
  UNION
    SELECT  unnest(parent) from concept_drg  join r on  r.pid=concept_drg.id
)
SELECT  jsonb_agg( DISTINCT pid) from (SELECT  'drg' || lpad(r.pid::text,6,'0') as pid  from r) as r2;
$$;

alter function get_drug_all_id(text) owner to postgres;

