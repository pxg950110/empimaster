create function f_traditional_diag(i_name text, i_code text, i_code_sys_id text, i_match_2 text, i_flag text, number character varying) returns character varying
    language plpgsql
as
$$
/*************************************************************************
*函数名称：f_traditional_diag
*函数功能描述：在sd_bank数据进bank表时中医疾病匹配字典
*函数参数：i_name（用来匹配字典的name字段），i_code（用来匹配字典的code字段），
        i_code_sys_id（函数使用的代码系统编号），i_match_2（其他用来匹配的字段），
        i_flag（标记需要查找的字典表），number（1表示查找id,2表示查找code,3表示查找name）
*函数返回值：需要查找的id,name或者code
*作者：邓雪聪
*函数创建日期：2018年11月08日
*函数修改日期：
*修改人：
*修改原因：
*版本：
*历史版本：
 *************************************************************************/
DECLARE
  v_result varchar DEFAULT  NULL ;
  v_name varchar;
BEGIN
  v_name=substring(i_name,0,position('【' in i_name));
	IF i_code_sys_id is NOT null and regexp_replace(i_code_sys_id,E'\\s+','','g')<>'' THEN
	IF i_code is not null and regexp_replace(i_code,E'\\s+','','g')<>'' and i_code<>'NULL'  THEN
		IF  i_name is NOT NULL and regexp_replace(i_name,E'\\s+','','g')<>'' THEN
      IF number='1' THEN
        select diag_id into v_result from mdm.diagnose
        where code_sys_id=i_code_sys_id::INT and diag_code=trim(i_code)
        and regexp_replace(diag_name,'([^\u4e00-\u9fa5])|([！@#￥%……&*—+={}|【】：“；《》？、○☆Ａ★Ｂ])','','g')=regexp_replace(v_name,'([^\u4e00-\u9fa5])|([！@#￥%……&*—+={}|【】：“；《》？、○☆Ａ★Ｂ])','','g');
        ELSEIF number='2' THEN
        select diag_code into v_result from mdm.diagnose
        where code_sys_id=i_code_sys_id::INT and diag_code=trim(i_code)
        and regexp_replace(diag_name,'([^\u4e00-\u9fa5])|([！@#￥%……&*—+={}|【】：“；《》？、○☆Ａ★Ｂ])','','g')=regexp_replace(v_name,'([^\u4e00-\u9fa5])|([！@#￥%……&*—+={}|【】：“；《》？、○☆Ａ★Ｂ])','','g');
        ELSE
        select diag_name into v_result from mdm.diagnose
        where code_sys_id=i_code_sys_id::INT and diag_code=trim(i_code)
        and regexp_replace(diag_name,'([^\u4e00-\u9fa5])|([！@#￥%……&*—+={}|【】：“；《》？、○☆Ａ★Ｂ])','','g')=regexp_replace(v_name,'([^\u4e00-\u9fa5])|([！@#￥%……&*—+={}|【】：“；《》？、○☆Ａ★Ｂ])','','g');
      END IF;
    END IF;
		END IF;
	END IF ;
  RETURN v_result;
END;
$$;

alter function f_traditional_diag(text, text, text, text, text, varchar) owner to postgres;

