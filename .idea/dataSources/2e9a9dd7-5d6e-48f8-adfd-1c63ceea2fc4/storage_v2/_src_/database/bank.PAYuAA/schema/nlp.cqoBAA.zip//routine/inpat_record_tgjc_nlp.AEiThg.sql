create function inpat_record_tgjc_nlp(patientid character varying, inpatid character varying, recordid character varying, recordtype character varying, content1 character varying, content2 character varying, content3 character varying, content4 character varying, content5 character varying) returns void
    language plpgsql
as
$$
DECLARE record_num int;
BEGIN
    SELECT count(1) into record_num FROM nlp.nlp_inhospital_record where record_id=recordid::integer;
    if record_num>0 then
        update nlp.nlp_inhospital_record set patient_id=patientid::integer,visit_id=inpatid::integer,visit_type='I',name=content1,physical_examination_json=content2::json,physical_examination_yes_json=content3::json
,physical_examination_no_json=content4::json,physical_examination_num_json=content5::json,nlp_time=current_timestamp where "type"=recordtype and  record_id=recordid::int;
         --工程已处理，先注释掉 update emr.inpat_medical_record set nlp_flag_tgjc='1' where record_id=recordid::integer;
    END IF;
     if record_num=0 THEN
    insert into nlp.nlp_inhospital_record(patient_id,type,record_id,visit_type,visit_id,name,physical_examination_json,physical_examination_yes_json,physical_examination_no_json,physical_examination_num_json,nlp_time) VALUES (patientid::integer,recordtype,recordid::integer,'I',inpatid::integer,content1,content2::json,content3::json,content4::json,content5::json,current_timestamp);
     --工程已处理，先注释掉  update emr.inpat_medical_record set nlp_flag_tgjc='1' where record_id=recordid::integer;
    END IF;
END;
$$;

alter function inpat_record_tgjc_nlp(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

