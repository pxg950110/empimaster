create function count_all(_sch character varying, _table character varying) returns integer
    language plpgsql
as
$$
declare
  count1 int;
  begin
    execute 'select count(1) from '||_sch||'.'||_table||';'
      into count1;
    return count1;
  end;
$$;

alter function count_all(varchar, varchar) owner to postgres;

