create function get_date() returns timestamp without time zone
    language plpgsql
as
$$
DECLARE   RESULT TIMESTAMP;
 BEGIN

    RESULT:=current_timestamp ;
     RETURN RESULT;
END;
$$;

alter function get_date() owner to postgres;

