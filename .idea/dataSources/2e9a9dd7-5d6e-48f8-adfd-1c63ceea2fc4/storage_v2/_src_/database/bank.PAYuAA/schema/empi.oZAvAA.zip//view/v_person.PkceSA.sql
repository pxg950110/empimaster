create view v_person(id, euid, identifier, name, pinyin, alias, birthday, idnumber, birthplace, nativeplace, gender,
                     marrystatus, ethnicity, nationality, carrer, operatetype, hospitalarea, sourcesystem, createdby,
                     createdtime, lastupdateby, lastupdatetime, identifierdomainname) as
SELECT a.id,
       a.euid,
       b.identifier,
       a.name,
       a.pinyin,
       a.alias,
       a.birth_day                                        AS birthday,
       a.id_number                                        AS idnumber,
       a.birth_place                                      AS birthplace,
       a.native_place                                     AS nativeplace,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.gender_id))       AS gender,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.marry_status_id)) AS marrystatus,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.ethnicity_id))    AS ethnicity,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.nationality_id))  AS nationality,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.carrer_id))       AS carrer,
       a.operate_type                                     AS operatetype,
       a.hospital_area                                    AS hospitalarea,
       a.source_system                                    AS sourcesystem,
       a.created_by                                       AS createdby,
       a.created_time                                     AS createdtime,
       a.last_update_by                                   AS lastupdateby,
       a.last_update_time                                 AS lastupdatetime,
       c.name                                             AS identifierdomainname
FROM ((empi.person a
    LEFT JOIN empi.person_identifier b ON (((a.id = b.person_id) AND (b.is_primary = '1'::smallint))))
         LEFT JOIN empi.identifier_domain c ON ((b.identifier_domain_id = c.id)));

alter table v_person
    owner to postgres;

