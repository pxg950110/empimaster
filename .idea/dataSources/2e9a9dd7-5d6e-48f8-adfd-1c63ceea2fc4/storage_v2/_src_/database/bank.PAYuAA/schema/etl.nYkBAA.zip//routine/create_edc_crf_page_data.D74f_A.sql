create function create_edc_crf_page_data(_subject_event_id bigint, _study_id bigint, _subject_id bigint, _event_def_id bigint, _crf_page_id bigint, _crf_version_id bigint, _content text DEFAULT NULL::text, _fill_source text DEFAULT NULL::text) returns character varying
    language plpgsql
as
$$
DECLARE
   result varchar ;
  BEGIN
  insert into edc.crf_page_data(content,fill_source,
        subject_event_id, study_id, subject_id, event_def_id, crf_page_id,
         crf_version_id, creator_user_id, creation_time, tenant_id, is_test,record_time,last_modifier_user_id,save_state) values
         (_content::json,_fill_source::json,_subject_event_id, _study_id, _subject_id, _event_def_id, _crf_page_id, _crf_version_id, 225,now(), 0, false,now(),225,1) returning id::varchar into result;
    RETURN  result;
    END ;
$$;

alter function create_edc_crf_page_data(bigint, bigint, bigint, bigint, bigint, bigint, text, text) owner to postgres;

