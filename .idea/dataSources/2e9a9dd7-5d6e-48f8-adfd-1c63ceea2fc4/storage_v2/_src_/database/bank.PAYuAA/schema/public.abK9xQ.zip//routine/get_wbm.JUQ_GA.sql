create function get_wbm(str character varying) returns character varying
    language plpgsql
as
$$
DECLARE strlen INTEGER;
        DECLARE result CHARACTER VARYING;
        DECLARE str1 CHARACTER VARYING;
        DECLARE i INT=1;
BEGIN
          result='';
          strlen=length(str);
          WHILE (i<=strlen) LOOP
            BEGIN
              str1=upper(substr(str,i,1));
              IF (get_byte(convert_to(str1,'GB18030')::bytea,0)<127) THEN
                BEGIN
                  result = result||str1;
                END;
                ELSEIF (ascii(str1)>=8544 AND ascii(str1)<=8552) THEN
               BEGIN
                  result = result||str1;
                END;
             ELSE
                BEGIN
                  result = result||coalesce((SELECT LEFT(col, 1) FROM public.library_wb WHERE position(str1 in col) > 0 LIMIT 1),'Z');
                END;
            END IF;
          i = i+1;
              END;
          END LOOP;
          RETURN result;
        END;
$$;

alter function get_wbm(varchar) owner to postgres;

