create function tools_str2array(_originstr character varying, _delimeter character varying) returns character varying[]
    language plpgsql
as
$$
declare _strres varchar(800);
declare _cindex INTEGER;
declare _arrIndex INTEGER;
DECLARE _arr_str VARCHAR(800)[];
DECLARE _tmp_str varchar(800);
DECLARE _debugStr VARCHAR(400);
BEGIN
_arrIndex:=1;
_strres:='';
_cindex:=1;
 
 
if _delimeter is NULL or "character_length"(_debugStr)<1 THEN
return _arr_str;
end IF;
--_strres:=_strres||'原始字符串是：'||_originStr;
while _cindex<"length"(_originStr) loop
--_strres :=_strres||'【这个是什么？】'||split_part(_originStr, _delimeter, _arrIndex);
_tmp_str:=split_part(_originStr, _delimeter, _arrIndex);
if "character_length"(_tmp_str)<1 then
exit;
end if;
_arr_str:=_arr_str|| _tmp_str;
_arrIndex:=_arrIndex+1;
END loop;
return _arr_str;
end;
$$;

alter function tools_str2array(varchar, varchar) owner to postgres;

