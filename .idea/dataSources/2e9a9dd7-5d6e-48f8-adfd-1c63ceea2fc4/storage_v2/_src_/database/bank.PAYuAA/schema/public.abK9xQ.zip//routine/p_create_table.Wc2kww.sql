create function p_create_table() returns void
    language plpgsql
as
$$
declare  f_ID int;
					 f_SCHEMANAME varchar(40);
					 f_TABLENAME varchar(40);
					 f_COLUMNNAME varchar(40);
					 f_COLUMNTYPE varchar(20);
					 f_COLUMNLEN varchar(40);
					 f_ISEMPTY varchar(4);
					 f_ISPRIMARY varchar(4);
					 f_INDENTITY varchar(4);
					 
	declare f_Sql text;
	declare f_count int;
	declare unbound_refcursor refcursor; 
	BEGIN 
		perform 1  from  "T_COLUMN"  where "UPDATEFLAG" is NULL;
		if  found then 		
		     
				open unbound_refcursor for execute 'select "ID","SCHEMANAME","TABLENAME","COLUMNNAME","COLUMNTYPE","COLUMNLEN","ISEMPTY","ISPRIMARY","INDENTITY"  from "T_COLUMN" where  "UPDATEFLAG" is NULL order by "ID"' ;    
				loop    
						fetch unbound_refcursor into f_ID,f_SCHEMANAME,f_TABLENAME,f_COLUMNNAME,f_COLUMNTYPE,f_COLUMNLEN,f_ISEMPTY,f_ISPRIMARY,f_INDENTITY;    								
						if found then  
				        EXECUTE 'CREATE SCHEMA IF NOT EXISTS '|| f_SCHEMANAME || ' AUTHORIZATION bank';	
							
							IF not EXISTS (SELECT 1 FROM pg_catalog.pg_tables  WHERE  lower(schemaname) = lower(f_SCHEMANAME) AND lower(tablename)  = lower(f_TABLENAME))  then 								
										f_Sql := 'create table if not exists ' || f_SCHEMANAME||'.'|| f_TABLENAME ||' ( ' || f_COLUMNNAME ;
										
										if f_INDENTITY = '是' then
											f_Sql := f_Sql || ' SERIAL '; 
										else 
											f_Sql := f_Sql || ' ' ||  f_COLUMNTYPE;
										end if ;
										
										if f_COLUMNTYPE='numeric' or f_COLUMNTYPE='varchar' or f_COLUMNTYPE='char'   then 
											f_Sql := f_Sql || ' ' || '(' || f_COLUMNLEN || ') ' ; 
										end if ;
										
										if f_ISEMPTY='否'   then 
											f_Sql := f_Sql || ' NOT NULL '  ; 
										end if;
																				
										if f_ISPRIMARY='是'   then 
											f_Sql := f_Sql || ' PRIMARY KEY '  ; 
										end if;		
										f_Sql := f_Sql ||  ')';
											
								else 
										f_Sql := 'alter  table ' || f_SCHEMANAME||'.'|| f_TABLENAME ||' add column ' || f_COLUMNNAME ;
										
										if f_INDENTITY = '是' then
											f_Sql := f_Sql || ' SERIAL '; 
										else 
											f_Sql := f_Sql || ' ' ||  f_COLUMNTYPE;
										end if ;
		
										if f_COLUMNTYPE='numeric' or f_COLUMNTYPE='varchar' or f_COLUMNTYPE='char' then 
											f_Sql := f_Sql || ' ' || '(' || f_COLUMNLEN || ') ' ; 
										end if ;
										
										if f_ISEMPTY='否'   then 
											f_Sql := f_Sql || ' NOT NULL '  ; 
										end if;
																				
										if f_ISPRIMARY='是'   then 
											f_Sql := f_Sql || ' PRIMARY KEY '  ; 
										end if;		
								end if ;
								
							  EXECUTE f_Sql;
							  --raise notice '%-%',f_ID,f_Sql;  
								update "T_COLUMN"  set "UPDATEFLAG"='1' where "ID"=f_ID ;
						else    
								exit;    
						end if;    
				end loop;    
				close unbound_refcursor;    
		   return;
		end if;
		return;
	END;
$$;

alter function p_create_table() owner to postgres;

