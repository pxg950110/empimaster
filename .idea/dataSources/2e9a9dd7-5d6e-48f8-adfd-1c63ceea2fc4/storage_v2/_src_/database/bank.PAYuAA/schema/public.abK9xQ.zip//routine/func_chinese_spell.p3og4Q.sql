create function func_chinese_spell(str character varying) returns character varying
    language plpgsql
as
$$
DECLARE word CHARACTER VARYING;
DECLARE code CHARACTER VARYING;
DECLARE i INTEGER;
DECLARE chnstr CHARACTER VARYING;
BEGIN 
   code='';
   i= 1;
  WHILE LENGTH(chnstr)>0 LOOP
word= SUBSTRING(chnstr,i,1); 
code= code || CASE WHEN (ASCII(word) BETWEEN 19968 AND 19968+20901) THEN
(
SELECT p FROM
(
SELECT 'A' as p,'驁' as w
UNION ALL SELECT 'B','簿'
UNION ALL SELECT 'C','錯'
UNION ALL SELECT 'D','鵽'
UNION ALL SELECT 'E','樲'
UNION ALL SELECT 'F','鰒'
UNION ALL SELECT 'G','腂'
UNION ALL SELECT 'H','夻'
UNION ALL SELECT 'J','攈'
UNION ALL SELECT 'K','穒'
UNION ALL SELECT 'L','鱳'
UNION ALL SELECT 'M','旀'
UNION ALL SELECT 'N','桛'
UNION ALL SELECT 'O','漚'
UNION ALL SELECT 'P','曝'
UNION ALL SELECT 'Q','囕'
UNION ALL SELECT 'R','鶸'
UNION ALL SELECT 'S','蜶'
UNION ALL SELECT 'T','籜'
UNION ALL SELECT 'W','鶩'
UNION ALL SELECT 'X','鑂'
UNION ALL SELECT 'Y','韻'
UNION ALL SELECT 'Z','咗'
) T 
WHERE w>=word ORDER BY p ASC LIMIT 1
) 
ELSE word END;
i = i + 1;
chnstr = SUBSTRING(chnstr,i,LENGTH(chnstr)-i + 1);
END LOOP;
RETURN code;
END;
$$;

alter function func_chinese_spell(varchar) owner to postgres;

