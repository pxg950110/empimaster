create function inpat_insert_or_update_visit_record() returns trigger
    language plpgsql
as
$$
/***********************************************************************************************
*函数名 :inpat_insert_or_update_visit_record
*函数功能描述 ： 住院就诊记录触发进入就诊总表  
*函数参数 ：
*函数返回值 ：trigger 触发器函数
*作者 ：pxg
*函数创建日期 ：2019-04-03
*函数修改日期 ：
*修改人 ：
*修改原因 ：
*版本 ：v1.0
*历史版本 ：
***********************************************************************************************/
declare
begin
   case TG_OP
     when 'INSERT' then
     insert into visit.visit_record(id,patient_id,pat_base_id,org_code,visit_type,visit_id,source_app,source_visit_id,source_inpat_no,patient_name,age,age_unit,age_day,pay_kind_id,pay_kind_code,pay_kind_name,insurance_kind_id,insurance_kind_code,insurance_kind_name,dept_id,dept_code,dept_name,doc_id,doc_code,doc_name,is_emergency,visit_time,out_time,major_diag_id,major_diag_code,major_diag_name,visit_state_id,visit_state_code,visit_state_name,is_valid,oper_id,oper_code,oper_name,oper_time,etl_time) values
                                  ( new.inpat_id,new.patient_id,new.pat_base_id,new.org_code,'I',new.inpat_id,new.source_app,
								  --暂存source_inpat_id  有需求再动
								  new.source_inpat_id,new.source_inpat_id,new.patient_name,new.age,new.age_unit,new.age_day,new.pay_kind_id,new.pay_kind_code,new.pay_kind_name,new.insurance_kind_id,new.insurance_kind_code,new.insurance_kind_name,new.in_dept_id,new.in_dept_code,new.in_dept_name,
								  new.attending_doc_id,new.attending_doc_code,new.attending_doc_name,false,new.in_time,new.out_time,new.major_diag_id,new.major_diag_code,new.major_diag_name,
								  new.inpat_state_id,new.inpat_state_code,new.inpat_state_name,new.is_valid,new.oper_id,new.oper_code,new.oper_name,new.oper_time,new.etl_time);

    when 'UPDATE' then
   update visit.visit_record set id=new.inpat_id,patient_id=new.patient_id,pat_base_id=new.pat_base_id,org_code=new.org_code,visit_type='I',source_app=new.source_app,source_visit_id=new.source_inpat_id, source_inpat_no=new.source_inpat_id,patient_name=new.patient_name,age=new.age,age_unit=new.age_unit,age_day=new.age_day,pay_kind_id=new.pay_kind_id,pay_kind_code=new.pay_kind_code,pay_kind_name=new.pay_kind_name,
              insurance_kind_id=new.insurance_kind_id,insurance_kind_code=new.insurance_kind_code,insurance_kind_name=new.insurance_kind_name,dept_id=new.in_dept_id,dept_code=new.in_dept_code,dept_name=new.in_dept_name,doc_id=new.attending_doc_id,doc_code=new.attending_doc_code,doc_name=new.attending_doc_name,visit_time=new.in_time,out_time=new.out_time,major_diag_id=new.major_diag_id,major_diag_name=new.major_diag_name,
			  visit_state_id=new.inpat_state_id,visit_state_code=new.inpat_state_code,visit_state_name=new.inpat_state_name,
			  is_valid=new.is_valid,oper_id=new.oper_id,oper_code=new.oper_code,oper_name=new.oper_name,oper_time=new.oper_time,etl_time=new.etl_time where visit_id=new.inpat_id and visit_type='I';
     when 'DELETE' then
    delete from visit.visit_record where org_code=old.org_code and visit_type='I' and source_app=old.source_app and  visit_id=old.inpat_id ;
    else
    return NULL;
    end case;
return NULL;
end;
$$;

alter function inpat_insert_or_update_visit_record() owner to postgres;

