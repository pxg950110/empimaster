create function hyw_get_info(dept_sys_code character varying, dept_code1 character varying, ward_code1 character varying) returns SETOF record
    language plpgsql
as
$$
DECLARE
  result RECORD;
BEGIN
  FOR result IN
(SELECT a.dept_id,a.dept_name ,b.dept_id as ward_id,b.dept_name as ward_name
 from mdm.department a
  LEFT JOIN
  mdm.department b on a.code_sys_id=b.code_sys_id
  --(SELECT b.dept_id as ward_id,b.dept_name as ward_name from mdm.department b
  where a.dept_code=dept_code1 and a.code_sys_id=dept_sys_code::integer
  and b.dept_code=ward_code1 and b.code_sys_id=dept_sys_code::integer
)LOOP
    RETURN NEXT result;
  END LOOP;
  RETURN ;
END;
$$;

alter function hyw_get_info(varchar, varchar, varchar) owner to postgres;

