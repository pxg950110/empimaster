create function bank_orders_out_recipe_map(dept_sys_code character varying, recipe_dept_code character varying, INOUT recipe_dept_name character varying, empl_sys_code character varying, recipe_doc_code character varying, INOUT recipe_doc_name character varying, recipe_state_sys_code character varying, recipe_state_code character varying, INOUT recipe_state_name character varying, OUT recipe_dept_id character varying, OUT recipe_doc_id character varying, OUT recipe_state_id character varying) returns record
    language plpgsql
as
$$
    -- Author:		ouyang.feng
-- Create date: 2018-6-2
-- Description:	查找门诊处方的标准化信息
--

BEGIN
--------开单科室
  SELECT  recipe_dept_id=dept_id,recipe_dept_name=dept_name from mdm.department
       where code_sys_id=dept_sys_code
           and dept_code=recipe_dept_code
           ;
--------开单医生
  SELECT  recipe_doc_id=empl_id,recipe_doc_name=empl_name from mdm.employee
       where code_sys_id=empl_sys_code
           and empl_code=recipe_doc_code
           ;
--------处方状态
   SELECT  recipe_state_id=code_id,recipe_state_name=name from mdm.code_set
       where code_sys_id=recipe_state_sys_code
           and code=recipe_state_code
           ;
  
  SELECT recipe_dept_name,recipe_doc_name,recipe_state_name,recipe_dept_id,recipe_doc_id,recipe_state_id;

END;
$$;

alter function bank_orders_out_recipe_map(varchar, varchar, inout varchar, varchar, varchar, inout varchar, varchar, varchar, inout varchar, out varchar, out varchar, out varchar) owner to postgres;

