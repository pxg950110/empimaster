create function count_elg(sche_name character varying, table_name character varying, flag integer) returns integer
    language plpgsql
as
$$
declare
    count1 int;
  begin
    if flag=1 then
 --   etl_flag1:=select count(1) from sche_name.table_name where etl_flag=1 ;
    --  execute 'select count(1) from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null ;'
      execute 'select count(1) from '||sche_name||'.'||table_name|| ' where  etl_flag=1 ;'
      into count1;
      elseif flag=2 then
      execute 'select count(1) from '||sche_name||'.'||table_name|| ' where  etl_flag=2 ;'
      into count1;
      elseif flag=3 then
      execute 'select count(1) from '||sche_name||'.'||table_name|| ' where  etl_flag=3 ;'
      into count1;
      elseif flag=4 then
      execute 'select count(1) from '||sche_name||'.'||table_name
      into count1;
      end if ;
      return count1;

  end;
$$;

alter function count_elg(varchar, varchar, integer) owner to postgres;

