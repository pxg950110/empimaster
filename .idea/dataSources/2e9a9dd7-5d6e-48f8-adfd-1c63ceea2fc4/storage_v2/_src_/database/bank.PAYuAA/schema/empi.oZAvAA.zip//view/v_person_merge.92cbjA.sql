create view v_person_merge(id, euid, identifier, identifier_domain_id, name, pinyin, alias, birth_day, id_number,
                           birth_place, native_place, identifier_domain, gender, marry_status, ethnicity, nationality,
                           carrer, operate_type, hospital_area, source_system, created_by, created_time, last_update_by,
                           last_update_time) as
SELECT a.id,
       a.euid,
       b.identifier,
       to_char(b.identifier_domain_id, '99999999'::text)       AS identifier_domain_id,
       a.name,
       a.pinyin,
       a.alias,
       a.birth_day,
       a.id_number,
       a.birth_place,
       a.native_place,
       (SELECT identifier_domain.name
        FROM empi.identifier_domain
        WHERE (identifier_domain.id = b.identifier_domain_id)) AS identifier_domain,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.gender_id))            AS gender,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.marry_status_id))      AS marry_status,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.ethnicity_id))         AS ethnicity,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.nationality_id))       AS nationality,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = a.carrer_id))            AS carrer,
       a.operate_type,
       a.hospital_area,
       a.source_system,
       a.created_by,
       a.created_time,
       a.last_update_by,
       a.last_update_time
FROM (empi.person a
         LEFT JOIN empi.person_identifier b ON ((a.id = b.person_id)));

alter table v_person_merge
    owner to postgres;

