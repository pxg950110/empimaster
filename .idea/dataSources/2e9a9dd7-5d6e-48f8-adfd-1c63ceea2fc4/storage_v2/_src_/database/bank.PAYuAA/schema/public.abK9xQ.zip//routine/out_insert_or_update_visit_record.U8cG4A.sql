create function out_insert_or_update_visit_record() returns trigger
    language plpgsql
as
$$
    --创建者：宋力力
---门诊就诊发生改变就诊总表相应的发生改变（插入、更新，删除）
declare
begin
   case
     when 'INSERT' then
           insert into visit.visit_record(id,patient_id,pat_base_id,org_code,visit_type,visit_id,source_app,source_visit_id,patient_name,age,age_unit,age_day,pay_kind_id,pay_kind_code,pay_kind_name,insurance_kind_id,insurance_kind_code,insurance_kind_name,dept_id,dept_name,doc_id,doc_name,is_emergency,visit_time,major_diag_id,major_diag_name,is_valid,oper_id,oper_time,etl_time,source_outpat_no,visit_state_id,visit_state_name) values
                                  (new.reg_id,new.patient_id,new.pat_base_id,new.org_code,'O',new.reg_id,new.source_app,new.source_reg_id,new.patient_name,new.age,new.age_unit,new.age_day,new.pay_kind_id,new.pay_kind_code,new.pay_kind_name,new.insurance_kind_id,new.insurance_kind_code,new.insurance_kind_name,new.dept_id,new.dept_name,new.doc_id,new.doc_name,new.is_emergency,new.reg_time,new.major_diag_id,new.major_diag_name,new.is_valid,new.oper_id,new.oper_time,new.etl_time,new.source_outpat_no,new.visit_state_id,new.visit_state_name);
        when 'UPDATE'  then
        update visit.visit_record set id=new.reg_id, patient_id=new.patient_id,pat_base_id=new.pat_base_id,org_code=new.org_code,visit_type='O',source_app=new.source_app,source_visit_id=new.source_reg_id,patient_name=new.patient_name,age=new.age,age_unit=new.age_unit,age_day=new.age_day,pay_kind_id=new.pay_kind_id,pay_kind_code=new.pay_kind_code,pay_kind_name=new.pay_kind_name,
              insurance_kind_id=new.insurance_kind_id,insurance_kind_code=new.insurance_kind_code,insurance_kind_name=new.insurance_kind_name,dept_id=new.dept_id,dept_name=new.dept_name,doc_id=new.doc_id,doc_name=new.doc_name,is_emergency=new.is_emergency,visit_time=new.reg_time,major_diag_id=new.major_diag_id,major_diag_name=new.major_diag_name,is_valid=new.is_valid,oper_id=new.oper_id,oper_time=new.oper_time,etl_time=new.etl_time,source_outpat_no=new.source_outpat_no,visit_state_id=new.visit_state_id, visit_state_name=new.visit_state_name where visit_id=new.reg_id and visit_type='O';
         when 'DELETE' then
       delete from  visit.visit_record where org_code=old.org_code and visit_type in ('E','O') and source_app=old.source_app and  visit_id=old.reg_id;
    else
    return null;
    end case;
return NULL;
end;
$$;

alter function out_insert_or_update_visit_record() owner to postgres;

