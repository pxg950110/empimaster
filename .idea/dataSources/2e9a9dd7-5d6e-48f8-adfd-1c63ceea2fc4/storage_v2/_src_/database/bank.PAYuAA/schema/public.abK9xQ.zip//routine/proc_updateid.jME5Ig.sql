create function proc_updateid() returns void
    language plpgsql
as
$$
Declare
 v_id int;
 v_newid varchar(50);
 v_num int;
 i_num int;
 v_medhod varchar(60);
i_medhod varchar(60);
 C_prescription  Cursor FOR SELECT source_recipe_id,source_detail_id,usage_name FROM orders.outpat_recipe_group;
begin
open C_prescription;
fetch C_prescription into v_id,v_num,v_medhod;
while FOUND LOOP
if v_medhod!~'[/]' then
i_num:=to_char(v_num,'9999999999');
i_medhod :=v_medhod;
end if;
if v_medhod!~'[/]' then
v_newid:= concat(to_char(v_id,'9999999999'),'-',to_char(v_num,'9999999999'));
raise notice'处方ID为：% 处方序号：% 途径:% 新的处方ID:%',to_char(v_id,'9999999999'),to_char(v_num,'9999999999'),v_medhod,v_newid;
elseif v_medhod~'[/]' THEN
v_newid:= concat(to_char(v_id,'9999999999'),'-',to_char(i_num,'9999999999'));
v_medhod:=i_medhod;
raise notice'处方ID为：% 处方序号：% 途径:% 新的处方ID:%',to_char(v_id,'9999999999'),to_char(v_num,'9999999999'),v_medhod,v_newid;
else
raise notice '异常情况';
fetch C_prescription into v_id,v_num,v_medhod;
end if;
end loop;
close C_prescription;
end
$$;

alter function proc_updateid() owner to postgres;

