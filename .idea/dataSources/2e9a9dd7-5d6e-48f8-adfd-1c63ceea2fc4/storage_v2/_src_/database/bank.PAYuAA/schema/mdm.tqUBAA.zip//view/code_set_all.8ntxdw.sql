create view code_set_all(all_id, all_code, all_name, code_sys_id, code_sys_code, code_sys_name) as
SELECT a.all_id,
       a.all_code,
       a.all_name,
       a.code_sys_id,
       b.code_sys_code,
       b.code_sys_name
FROM ((SELECT bed.bed_id   AS all_id,
              bed.bed_code AS all_code,
              bed.bed_name AS all_name,
              bed.code_sys_id
       FROM mdm.bed
       UNION
       SELECT code_set.code_id AS all_id,
              code_set.code    AS all_code,
              code_set.name    AS all_name,
              code_set.code_sys_id
       FROM mdm.code_set
       WHERE (code_set.code_sys_id IS NOT NULL)
       UNION
       SELECT department.dept_id   AS all_id,
              department.dept_code AS all_code,
              department.dept_name AS all_name,
              department.code_sys_id
       FROM mdm.department
       UNION
       SELECT diagnose.diag_id   AS all_id,
              diagnose.diag_code AS all_code,
              diagnose.diag_name AS all_name,
              diagnose.code_sys_id
       FROM mdm.diagnose
       UNION
       SELECT drug.drug_id    AS all_id,
              drug.drug_code  AS all_code,
              drug.trade_name AS all_name,
              drug.code_sys_id
       FROM mdm.drug
       UNION
       SELECT employee.empl_id   AS all_id,
              employee.empl_code AS all_code,
              employee.empl_name AS all_name,
              employee.code_sys_id
       FROM mdm.employee
       UNION
       SELECT item.item_id   AS all_id,
              item.item_code AS all_code,
              item.item_name AS all_name,
              item.code_sys_id
       FROM mdm.item
       WHERE (item.code_sys_id IS NOT NULL)
       UNION
       SELECT lis_item.item_id   AS all_id,
              lis_item.item_code AS all_code,
              lis_item.item_name AS all_name,
              lis_item.code_sys_id
       FROM mdm.lis_item
       UNION
       SELECT operation.operation_id   AS all_id,
              operation.operation_code AS all_code,
              operation.operation_name AS all_name,
              operation.code_sys_id
       FROM mdm.operation) a
         LEFT JOIN mdm.code_system b ON ((a.code_sys_id = b.code_sys_id)));

alter table code_set_all
    owner to postgres;

