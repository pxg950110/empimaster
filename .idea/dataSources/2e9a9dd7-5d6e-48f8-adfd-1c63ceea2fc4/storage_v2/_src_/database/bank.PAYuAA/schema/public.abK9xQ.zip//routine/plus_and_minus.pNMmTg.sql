create function plus_and_minus(a numeric, b numeric, sd_org_code character varying, sd_soucre_app character varying, sd_source_reg_id character varying, sd_patient_no character varying, OUT c numeric) returns numeric
    language sql
as
$$
select a+b;

  SELECT  reg_id,patient_id from visit.outpatient_record
       where source_app=sd_soucre_app
           and org_code=sd_org_code
           and source_reg_id=sd_source_reg_id;

   select a-b;
$$;

alter function plus_and_minus(numeric, numeric, varchar, varchar, varchar, varchar, out numeric) owner to postgres;

