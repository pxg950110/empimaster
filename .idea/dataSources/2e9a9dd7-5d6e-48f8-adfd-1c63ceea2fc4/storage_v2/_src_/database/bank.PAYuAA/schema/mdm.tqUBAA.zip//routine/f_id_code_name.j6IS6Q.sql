create function f_id_code_name(i_name text, i_code text, i_code_sys_id text, i_match_2 text, i_flag text, number character varying) returns character varying
    language plpgsql
as
$$
/*************************************************************************
*函数名称：f_id_code_name
*函数功能描述：在sd_bank数据进bank表时对需要匹配字典的字段做处理
*函数参数：i_name（用来匹配字典的name字段），i_code（用来匹配字典的code字段），
        i_code_sys_id（函数使用的代码系统编号），i_match_2（其他用来匹配的字段），
        i_flag（标记需要查找的字典表），number（1表示查找id,2表示查找code,3表示查找name）
*函数返回值：需要查找的id,name或者code
*作者：邓雪聪
*函数创建日期：2018年06月14日
*函数修改日期：
*修改人：皮小怪
*修改原因：修改参数类型 修改传入NULL出错问题
*版本：2018/06/15
*修改人：皮小怪
*修改原因：修改到mdm域下
*版本：2019/04/20
*历史版本：
 *************************************************************************/
DECLARE
  v_result varchar DEFAULT  NULL ;
	v_search_column_name varchar;
	v_table_name varchar;
	v_match_column_name varchar;
	v_value varchar;
	v_sql varchar;
	v_code_flag int;
BEGIN
	IF i_code_sys_id is NOT null and regexp_replace(i_code_sys_id,E'\\s+','','g')<>'' THEN
	IF i_code is not null and regexp_replace(i_code,E'\\s+','','g')<>'' and i_code<>'NULL'  THEN
		v_value:=regexp_replace(i_code,E'\\s+','','g')::varchar;
		v_code_flag=1;
		ELSEIF  i_name is NOT NULL and regexp_replace(i_name,E'\\s+','','g')<>'' THEN
			v_value:=regexp_replace(regexp_replace(i_name,E'\\s+','','g')::varchar,'[\x27]','''''','g');
		v_code_flag=0;
		END IF;
	IF v_code_flag=1 OR v_code_flag=0 THEN
		select table_name,search_cloumn_name,match_cloumn_name
  into v_table_name,v_search_column_name,v_match_column_name
	from mdm.search_mdm_information
  where table_flag=i_flag::varchar and cloumn_flag=number and code_flag=cast(v_code_flag as BOOLEAN);
	if i_flag='item' THEN
	v_sql:='select '||v_search_column_name||' from mdm.'||v_table_name||' where code_sys_id='||i_code_sys_id::integer||' and '||v_match_column_name||'='''||v_value||''' and item_class='''||i_match_2::varchar||''';';
	execute v_sql into v_result;
	else
	v_sql:='select '||v_search_column_name||' from mdm.'||v_table_name||' where code_sys_id='||i_code_sys_id::integer||' and '||v_match_column_name||'='''||v_value||''';';
  execute v_sql into v_result;
	END IF;
	END IF;
	END IF ;
  RETURN v_result;
END;
$$;

alter function f_id_code_name(text, text, text, text, text, varchar) owner to postgres;

