create function age_format(birth_date timestamp without time zone) returns text
    language plpgsql
as
$$
DECLARE
  age_day int;
BEGIN
  age_day =  date_part('day', current_date::timestamp - birth_date::timestamp);
  RETURN CASE WHEN (age_day / 365) >=2 THEN  (age_day / 365) || ' 岁'
          WHEN (age_day / 365) <2 AND age_day >=60 THEN (age_day / 30) || ' 月 ' || (age_day - (age_day/30)*30)|| ' 天'
            ELSE age_day || ' 天'
         END;
  END ;
$$;

alter function age_format(timestamp) owner to postgres;

