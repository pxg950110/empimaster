create function insert_patient_infos(_org_code character varying, _empi character varying, _patient_name character varying, _spell_code character varying, _wb_code character varying, _sex_code character varying, _sex_name character varying, _birth_date character varying, _birth_address character varying, _id_type_code character varying, _id_type_name character varying, _id_no character varying, _country_code character varying, _country_name character varying, _nation_code character varying, _nation_name character varying, _marriage_code character varying, _marriage_name character varying, _profession character varying, _abo_code character varying, _abo_name character varying, _rh_code character varying, _rh_name character varying, _native_place character varying, _account_address character varying, _phone character varying, _mail character varying, _contact_name character varying, _contact_relation_code character varying, _contact_relation_name character varying, _contact_phone character varying, _contact_address character varying, _contact_zip character varying, _home_address character varying, _home_phone character varying, _home_zip character varying, _work_address character varying, _work_phone character varying, _work_zip character varying, _note character varying, _system_code character varying, _create_oper_id character varying, _update_oper_id character varying, _is_valid character varying, _source_id_type character varying, _source_patient_no character varying, _card_type character varying, _card_no character varying) returns void
    language plpgsql
as
$$
    -- Author:		lizhen
-- Create date: 2017-10-10 11:27
-- Description:	批量执行导入患者基本信息并建立主从标识关系
--update:2017-11-13 新增重复导入患者数据，patient_base_info表更新

DECLARE _master_info_count INT; --患者主记录计数
          _master_info_id INT; --患者patient_id
          _identifier_master_id INT; --主标识编号
          _identifier_slave_id INT; --从标识编号
          _identifier_card_slave_id INT; --卡号从标识编号
          _identifier_slave_count  INT; --从标识计数
         _identifier__card_slave_count  INT; --卡号从标识计数
BEGIN

    SELECT  count(patient_id) INTO _master_info_count FROM patient.patient_master_info WHERE empi=_empi;

    IF _master_info_count=0 THEN
    --若患者不存在

      --patient_master_info表中插入患者主记录数据

      INSERT INTO patient.patient_master_info VALUES(DEFAULT ,_org_code,_empi,_patient_name,null,null,_spell_code,_wb_code,_sex_code,_sex_name,_birth_date::DATE ,
      _birth_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_id_type_code,_id_type_name,_id_no,_country_code,_country_name,_nation_code,_nation_name,_marriage_code,
      _marriage_name,_profession,_abo_code,_abo_name,_rh_code,_rh_name,_native_place,_account_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_phone,NULL ,null,
      _mail,NULL ,NULL ,_contact_name,NULL ,_contact_relation_code,_contact_relation_name,_contact_phone,_contact_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_contact_zip,
      _home_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_home_phone,_home_zip,_work_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_work_phone,_work_zip,_note,_system_code,
      current_timestamp,_create_oper_id::INTEGER,_update_oper_id::INTEGER,NULL ,_is_valid::BOOLEAN,current_timestamp) RETURNING patient_id INTO _master_info_id ;

      --病人标识信息表中插入数据

      INSERT INTO patient.patient_identifier VALUES (DEFAULT,_master_info_id::VARCHAR(50),'PatientId',current_timestamp,'Synyi') RETURNING id INTO _identifier_master_id;



      INSERT INTO patient.patient_identifier VALUES (DEFAULT,_source_patient_no,_source_id_type,current_timestamp,_system_code) RETURNING  id INTO _identifier_slave_id;




      --建立病人标识关系

        INSERT INTO patient.patient_id_relationship VALUES(DEFAULT,_identifier_master_id,_identifier_slave_id,1,current_timestamp); --主标识与从标识关系

      IF _card_no<>''THEN --若卡号不为空

         INSERT INTO patient.patient_identifier VALUES (DEFAULT,_card_no,_card_type,current_timestamp,_system_code) RETURNING  id INTO _identifier_card_slave_id;


        --建立主标识与卡号从标识关系

          INSERT INTO patient.patient_id_relationship VALUES(DEFAULT,_identifier_master_id,_identifier_card_slave_id,1,current_timestamp);


      END IF;


      --patient_base_info表中插入病人基本信息数据

      INSERT INTO patient.patient_base_info VALUES(DEFAULT,_org_code,_master_info_id,_system_code,_source_id_type,_source_patient_no,_card_type,_card_no,_patient_name,NULL ,NULL ,
      _spell_code,_wb_code,_sex_code,_sex_name,_birth_date::DATE ,_birth_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_id_type_code,_id_type_name,_id_no,_country_code,_country_name,
      _nation_code,_nation_name,_marriage_code,_marriage_name,_profession,_abo_code,_abo_name,_rh_code,_rh_name,_native_place,_account_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,
      _phone,NULL ,NULL ,_mail,NULL ,NULL ,_contact_name,NULL ,_contact_relation_code,_contact_relation_name,_contact_phone,_contact_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_contact_zip,
      _home_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_home_phone,_home_zip,_work_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_work_phone,_work_zip,_note,current_timestamp,_create_oper_id::INTEGER,
      _update_oper_id::INTEGER,NULL ,_is_valid::BOOLEAN,current_timestamp);


    END IF;


    IF _master_info_count>0 THEN
      --若患者存在

      SELECT patient_id into _master_info_id FROM patient.patient_master_info WHERE empi=_empi;

        --更新patient_master_info表中患者主记录数据
       UPDATE patient.patient_master_info SET patient_name=_patient_name,spell_code=_spell_code,wb_code=_wb_code,sex_code=_sex_code,sex_name=_sex_name,birth_date=_birth_date::DATE ,birth_address=_birth_address,
         id_type_code=_id_type_code,id_type_name=_id_type_name,id_no=_id_no,country_code=_country_code,country_name=_country_name,nation_code=_nation_code,nation_name=_nation_name,
         marriage_code=_marriage_code,marriage_name=_marriage_name,profession=_profession,abo_code=_abo_code,abo_name=_abo_name,rh_code=_rh_code,rh_name=_rh_name,
         native_place=_native_place,account_address=_account_address,phone=_phone,mail=_mail,contact_name=_contact_name,contact_relation_code=_contact_relation_code,
         contact_relation_name=_contact_relation_name,contact_phone=_contact_phone,contact_address=_contact_address,contact_zip=_contact_zip,home_address=_home_address,
         home_phone=_home_phone,home_zip=_home_zip,work_address=_work_address,work_phone=_work_phone,work_zip=_work_zip,note=_note,system_code=_system_code,update_oper_id=_update_oper_id::INTEGER,
         update_time=current_timestamp,is_valid=_is_valid::BOOLEAN,etl_time=current_timestamp
         WHERE empi=_empi;

       --检索病人标识信息表中是否存在对应从标识
        SELECT count(id) INTO _identifier_slave_count  FROM patient.patient_identifier WHERE identifier=_source_patient_no AND id_type=_source_id_type;

         IF _identifier_slave_count=0 THEN
           --若检索不到对应的从标识数据则新增标识记录

           INSERT INTO patient.patient_identifier VALUES(DEFAULT ,_source_patient_no,_source_id_type,CURRENT_TIMESTAMP,_system_code) RETURNING id INTO _identifier_slave_id;


                 --检索主标识记录
                   SELECT  id INTO _identifier_master_id  FROM  patient.patient_identifier WHERE identifier=_master_info_id::VARCHAR(50) AND id_type='PatientId';

                 --建立病人标识关系
                   INSERT INTO patient.patient_id_relationship VALUES(DEFAULT,_identifier_master_id,_identifier_slave_id,1,current_timestamp);



                  IF _card_no<>'' THEN --若卡号不为空

                   --检索病人标识信息表中是否存在对应卡号从标识
                  SELECT count(id) INTO _identifier__card_slave_count  FROM patient.patient_identifier WHERE identifier=_card_no AND id_type=_card_type;

                     IF _identifier__card_slave_count=0 THEN  --无此卡病人标识信息记录


                      INSERT INTO patient.patient_identifier VALUES (DEFAULT,_card_no,_card_type,current_timestamp,_system_code) RETURNING  id INTO _identifier_card_slave_id;

                      --建立主标识与卡号从标识关系

                      INSERT INTO patient.patient_id_relationship VALUES(DEFAULT,_identifier_master_id,_identifier_card_slave_id,1,current_timestamp);


                     END IF;


                 END IF;



              --patient_base_info表中插入病人基本信息数据

               INSERT INTO patient.patient_base_info VALUES(DEFAULT,_org_code,_master_info_id,_system_code,_source_id_type,_source_patient_no,_card_type,_card_no,_patient_name,NULL ,NULL ,
               _spell_code,_wb_code,_sex_code,_sex_name,_birth_date::DATE ,_birth_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_id_type_code,_id_type_name,_id_no,_country_code,_country_name,
               _nation_code,_nation_name,_marriage_code,_marriage_name,_profession,_abo_code,_abo_name,_rh_code,_rh_name,_native_place,_account_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,
               _phone,NULL ,NULL ,_mail,NULL ,NULL ,_contact_name,NULL ,_contact_relation_code,_contact_relation_name,_contact_phone,_contact_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_contact_zip,
               _home_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_home_phone,_home_zip,_work_address,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL,_work_phone,_work_zip,_note,current_timestamp,_create_oper_id::INTEGER,
               _update_oper_id::INTEGER,NULL ,_is_valid::BOOLEAN,current_timestamp);


         END IF;
        IF _identifier_slave_count<>0 THEN

          UPDATE patient.patient_base_info SET card_type=_card_type,card_no=_card_no,patient_name=_patient_name,spell_code=_spell_code,wb_code=_wb_code,sex_code=_sex_code,sex_name=_sex_name,birth_date=_birth_date::DATE ,
            birth_address=_birth_address,id_type_code=_id_type_code,id_no=_id_no,country_code=_country_code,country_name=_country_name,nation_code=_nation_code,nation_name=_nation_name,marriage_code=_marriage_code,
            marriage_name=_marriage_name,profession=_profession,abo_code=_abo_code,abo_name=_abo_name,rh_code=_rh_code,rh_name=_rh_name,native_place=_native_place,account_address=_account_address,phone=_phone,mail=_mail,
            contact_name=_contact_name,contact_relation_code=_contact_relation_code,contact_relation_name=_contact_relation_name,contact_phone=_contact_phone,contact_address=_contact_address,contact_zip=_contact_zip,
            home_address=_home_address,home_phone=_home_phone,home_zip=_home_zip,work_address=_work_address,work_phone=_work_phone,work_zip=_work_zip,update_oper_id=_create_oper_id::INTEGER,update_time=current_timestamp,
            is_valid=TRUE,etl_time=current_timestamp WHERE source_patient_no=_source_patient_no;

        END IF;




    END IF;



END;
$$;

alter function insert_patient_infos(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

