create view v_patient_statistics(person_id, euid, score, quality, name, pinyin, alias, birth_day, id_number, gender,
                                 marry_status, ethnicity, nationality, carrer, birth_place, native_place, operatetype1,
                                 hospitalarea, sourcesystem, created_by, created_time, last_update_by, last_update_time,
                                 link_id, major_euid, major_person_id, minor_euid, minor_person_id, operatetype2,
                                 create_by, create_time) as
SELECT b.id                                                     AS person_id,
       b.euid,
       b.score,
       b.quality,
       b.name,
       b.pinyin,
       b.alias,
       b.birth_day,
       b.id_number,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.gender_id))             AS gender,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.marry_status_id))       AS marry_status,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.ethnicity_id))          AS ethnicity,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.nationality_id))        AS nationality,
       (SELECT code_value_detail.value
        FROM empi.code_value_detail
        WHERE (code_value_detail.id = b.carrer_id))             AS carrer,
       b.birth_place,
       b.native_place,
       b.operate_type                                           AS operatetype1,
       b.hospital_area                                          AS hospitalarea,
       b.source_system                                          AS sourcesystem,
       b.created_by,
       b.created_time,
       b.last_update_by,
       b.last_update_time,
       a.id                                                     AS link_id,
       a.major_euid,
       a.major_person_id,
       a.minor_euid,
       a.minor_person_id,
       to_char((a.operate_type)::double precision, '999'::text) AS operatetype2,
       a.create_by,
       a.create_time
FROM (empi.link a
         LEFT JOIN empi.person b ON ((a.major_person_id = b.id)));

alter table v_patient_statistics
    owner to postgres;

