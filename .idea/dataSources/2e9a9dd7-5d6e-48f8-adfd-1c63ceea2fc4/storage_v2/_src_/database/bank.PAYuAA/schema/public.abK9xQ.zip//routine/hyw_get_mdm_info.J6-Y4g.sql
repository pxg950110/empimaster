create function hyw_get_mdm_info(code_sys_code character varying, code1 character varying, name character varying) returns SETOF record
    language plpgsql
as
$$
DECLARE
result RECORD;
BEGIN
  IF code1  IS NOT NULL then 
 FOR result in (SELECT code_id ,code_set.name from mdm.code_set
 where code_sys_id=code_sys_code::INTEGER
  and code=code1)LOOP
   return NEXT result;
 END LOOP;
    ELSE 
    result=NULL ;
    END IF ;
  
END;
$$;

alter function hyw_get_mdm_info(varchar, varchar, varchar) owner to postgres;

