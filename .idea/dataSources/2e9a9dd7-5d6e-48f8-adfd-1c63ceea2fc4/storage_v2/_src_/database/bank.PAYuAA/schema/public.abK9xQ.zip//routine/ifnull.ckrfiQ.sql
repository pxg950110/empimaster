create function ifnull(colue double precision) returns character varying
    language plpgsql
as
$$
declare
    result varchar;
  begin
    if colue is null then
      result:='null';
    else
      result:= colue::varchar;
      end if ;
      return result;
  end;
$$;

alter function ifnull(double precision) owner to postgres;

