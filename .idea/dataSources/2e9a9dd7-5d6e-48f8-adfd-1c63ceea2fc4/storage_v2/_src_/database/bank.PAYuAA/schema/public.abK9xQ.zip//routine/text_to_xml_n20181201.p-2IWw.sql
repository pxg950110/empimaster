create function text_to_xml_n20181201(content text) returns xml
    language plpgsql
as
$$
    /**
     *处理一些特殊字符
     */
  DECLARE
    result xml;
    content1 text;
  BEGIN
    content1:=content;
     select text_to_xml_new(content1) into result;
     if result is null THEN
        SELECT  replace(content1,'<恩度>','恩度')  into content1;
         select text_to_xml_new(content1) into result;
     END IF ;
    IF result is null then
       SELECT  replace(content1,'<里葆多>','里葆多')  into content1;
         select text_to_xml_new(content1) into result;
    END IF;
    IF result is null THEN
       SELECT  replace(content1,'<0.005','小于0.005')  into content1;
         select text_to_xml_new(content1) into result;
    END IF;--
    IF result is null THEN
       SELECT  replace(content1,'<50','小于50')  into content1;
         select text_to_xml_new(content1) into result;
    END IF;
      RETURN
          result;
  END;
$$;

alter function text_to_xml_n20181201(text) owner to postgres;

