create function get_age_day_unit(first_time timestamp without time zone, end_time timestamp without time zone, num integer, OUT result character varying) returns character varying
    language plpgsql
as
$$
/**
#@author:皮小怪
#功能：获取年龄、年龄天数、年龄单位
#参数：first_time:较大的时间 end_time：较小的时间 num：1表示年龄 2表示年龄单位 3表示年龄天数
#创建日期：2018/08/18
 */
  BEGIN
  IF num=1 THEN
  result:=( SELECT CASE WHEN date_part('day',first_time-end_time)>=365 THEN (date_part('day',first_time-end_time)/365)::INT
  WHEN date_part('day',first_time-end_time) BETWEEN 30 AND 365 THEN
    (date_part('day',first_time-end_time)/30)::INT
    WHEN date_part('day',first_time-end_time) <0 THEN NULL
    ELSE
    date_part('day',first_time-end_time)::int END);
  ELSEIF num=2 THEN

  result:= (SELECT CASE WHEN date_part('day',first_time-end_time)>=365 THEN '岁'
  WHEN date_part('day',first_time-end_time) BETWEEN 30 AND 365 THEN '月'
    WHEN date_part('day',first_time-end_time) IS NULL THEN NULL
     WHEN date_part('day',first_time-end_time) <0 THEN NULL
    ELSE  '天' END );
  ELSEIF num=3 THEN
 result:=(SELECT  CASE WHEN date_part('day',first_time-end_time) >=0 THEN date_part('day',first_time-end_time) ELSE NULL END );
  ELSE
      result:=NULL ;
  END IF ;
  END ;
$$;

alter function get_age_day_unit(timestamp, timestamp, integer, out varchar) owner to postgres;

