create function istimestamp(text) returns boolean
    immutable
    strict
    language plpgsql
as
$$
DECLARE x timestamp;
BEGIN
    x = to_timestamp($1, 'yyyy-mm-dd HH24:MI:SS');
    RETURN TRUE;
EXCEPTION WHEN others THEN
    RETURN FALSE;
END;
$$;

alter function istimestamp(text) owner to postgres;

