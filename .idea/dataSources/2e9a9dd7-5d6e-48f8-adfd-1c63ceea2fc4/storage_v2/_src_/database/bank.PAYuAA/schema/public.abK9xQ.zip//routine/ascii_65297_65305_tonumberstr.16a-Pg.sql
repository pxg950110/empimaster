create function ascii_65297_65305_tonumberstr(str character varying) returns character varying
    language plpgsql
as
$$
DECLARE
    v_length int;
    v_i int DEFAULT 1;
    v_result varchar DEFAULT '';
    v_temp INT;
  BEGIN
    --查询字符长度
    select length(str) INTO  v_length;
    --
    WHILE v_i<v_length LOOP
    select ascii(substr(str,v_i,1))::INT into v_temp;
      IF v_temp >=65297 and v_temp<=65305 THEN
          SELECT v_temp-65248 into v_temp;
      END IF;
      select v_result||chr(v_temp) into v_result;
      v_i:=v_i+1;
  END LOOP;
    return
    v_result;
  END;
$$;

alter function ascii_65297_65305_tonumberstr(varchar) owner to postgres;

