create function soda_count(clom character varying, _sch text, _table text, flag integer) returns integer
    language plpgsql
as
$$
declare
  count1 int;
begin
  if flag = 1 then
  execute 'select count(1) from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null ;' 
    into count1;
  elseif flag = 2 then
  execute 'select count(1) from '||_sch||'.'||_table||' where '||clom||' isnull'
    into count1;
  elseif flag=3 then
    execute 'select count(1) from ( select distinct patient_id from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null '||' ) a;'
    into count1;
    elseif flag=4 then
    execute ' select '||clom||' from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null '||'and '||'trim('||clom||') <> '||' '' '  ||' group '||'  by '||clom||' order '||' by  '||' count(1) '||' desc '||' limit '|| ' 10 ;'
    into count1;
  end if ;
  return count1;
end;
$$;

alter function soda_count(varchar, text, text, integer) owner to postgres;

