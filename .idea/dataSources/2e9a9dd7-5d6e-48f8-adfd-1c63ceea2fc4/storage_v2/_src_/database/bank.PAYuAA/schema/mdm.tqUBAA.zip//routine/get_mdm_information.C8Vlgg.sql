create function get_mdm_information(itemclass character varying, code1 character varying, code_sys_id1 integer, flag character varying, number character varying) returns character varying
    language plpgsql
as
$$
/**************
目前未实现lis_item表的获取,床位字典的获取用get_mdm_information_bed
 此函数的功能：实现获取id,code,name
 创建人：宋力力
 入参详解：itemclass（item表项目类别）,code1（原始的code）,code_sys_id1（字典标识），flag（用来判别取得是code_set中的信息还是其他相关字典表中的信息）,number（用来标识取id,code,name）
 返回值：得到相关的name(number=3)，code(number=2)，id（number=1）
 创建日期：2018/06/13
 **************/
DECLARE
  result_id varchar;
  result_name varchar;
  result_code varchar DEFAULT code1;
BEGIN
if flag not in('diagnose','bed','department','employee','drug','item','operation','lis_item') then
    if number='1' then
    select code_id::varchar into result_id from mdm.code_set where code_sys_id=code_sys_id1 and code=code1;
    ELSEIF number='2' THEN
    select code into result_code from mdm.code_set where code_sys_id=code_sys_id1 and code=code1;
    ELSEIF number='3' THEN
    select name into result_name from mdm.code_set where code_sys_id=code_sys_id1 and code=code1;
    END IF;
ELSEIF flag in('diagnose') then --诊断
     if number='1' then
    select diag_id::varchar into result_id from mdm.diagnose where code_sys_id=code_sys_id1 and diag_code=code1;
    ELSEIF number='2' THEN
    select diag_code into result_code from mdm.diagnose where code_sys_id=code_sys_id1 and diag_code=code1;
    ELSEIF number='3' THEN
    select diag_name into result_name from mdm.diagnose where code_sys_id=code_sys_id1 and diag_code=code1;
    END IF;
ELSEIF flag in('department') then --科室
    if number='1' then
    select dept_id::varchar into result_id from mdm.department where code_sys_id=code_sys_id1 and dept_code=code1;
    ELSEIF number='2' THEN
    select dept_code into result_code from mdm.department where code_sys_id=code_sys_id1 and dept_code=code1;
    ELSEIF number='3' THEN
    select dept_name into result_name from mdm.department where code_sys_id=code_sys_id1 and dept_code=code1;
    END IF;
ELSEIF flag in('employee') then --人员
     if number='1' then
    select empl_id::varchar into result_id from mdm.employee where code_sys_id=code_sys_id1 and empl_code=code1;
    ELSEIF number='2' THEN
    select empl_code into result_code from mdm.employee where code_sys_id=code_sys_id1 and empl_code=code1;
    ELSEIF number='3' THEN
    select empl_name into result_name from mdm.employee where code_sys_id=code_sys_id1 and empl_code=code1;
    END IF;
ELSEIF flag in('drug') then --药品
     if number='1' then
    select drug_id::varchar into result_id from mdm.drug where code_sys_id=code_sys_id1 and drug_code=code1;
    ELSEIF number='2' THEN
    select drug_code into result_code from mdm.drug where code_sys_id=code_sys_id1 and drug_code=code1;
    ELSEIF number='3' THEN
    select trade_name into result_name from mdm.drug where code_sys_id=code_sys_id1 and drug_code=code1;
    END IF;
ELSEIF flag in('item') then --项目
     if number='1' then
    select item_id::varchar into result_id from mdm.item where code_sys_id=code_sys_id1 and item_code=code1 and item_class=itemclass;
    ELSEIF number='2' THEN
    select item_code into result_code from mdm.item where code_sys_id=code_sys_id1 and item_code=code1 and item_class=itemclass;
    ELSEIF number='3' THEN
    select item_name into result_name from mdm.item where code_sys_id=code_sys_id1 and item_code=code1 and item_class=itemclass;
    END IF;
ELSEIF flag in('operation') then --手术
     if number='1' then
    select operation_id::varchar into result_id from mdm.operation where code_sys_id=code_sys_id1 and operation_code=code1;
    ELSEIF number='2' THEN
    select operation_code into result_code from mdm.operation where code_sys_id=code_sys_id1 and operation_code=code1;
    ELSEIF number='3' THEN
    select operation_name into result_name from mdm.operation where code_sys_id=code_sys_id1 and operation_code=code1;
    END IF;
  ELSEIF flag in('lis_item') then --检验项目(是在数据字典与业务数据一对一的情况，元数据的code已经转换成了样本与原始code拼接形式)
     if number='1' then
    select item_id::varchar into result_id from mdm.lis_item where code_sys_id=code_sys_id1 and item_code=code1;
    ELSEIF number='2' THEN
    select item_code into result_code from mdm.lis_item  where code_sys_id=code_sys_id1 and item_code=code1;
    ELSEIF number='3' THEN
    select item_name into result_name from mdm.lis_item  where code_sys_id=code_sys_id1 and item_code=code1;
    END IF;
END IF;
  IF number='1' THEN
   RETURN result_id;
  ELSEIF number='2' THEN
    RETURN result_code;
  ELSEIF number='3' THEN
    RETURN result_name;
  END IF;
END;
$$;

alter function get_mdm_information(varchar, varchar, integer, varchar, varchar) owner to postgres;

