create function ifnull(colue character varying) returns character varying
    language plpgsql
as
$$
declare
    result varchar;
  begin
    if colue is null then
      result:='null';
    else
      result:= colue;
      end if ;
      return result;
  end;
$$;

alter function ifnull(varchar) owner to postgres;

