create function age_day_format(age_day integer, OUT age_day_format text) returns text
    language sql
as
$$
SELECT
       CASE WHEN (age_day / 365) >=2 THEN  (age_day / 365) || ' 岁'
          WHEN (age_day / 365) <2 AND age_day >=60 THEN (age_day / 30) || ' 月 ' || (age_day - (age_day/30))|| ' 天'
            ELSE age_day || ' 天'
         END as age_day_format
$$;

alter function age_day_format(integer, out text) owner to postgres;

