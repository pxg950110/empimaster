create view v_suspect_best_record_person(id, group_by, euid, minor_euid, person_id, name, score, is_valid,
                                         suspect_status, last_update_by, last_update_time, birth_day, birth_place,
                                         id_number, gender, marry_status, ethnicity, nationality, carrer) as
    SELECT a.id,
           ''::text                                           AS group_by,
           a.major_euid                                       AS euid,
           a.minor_euid,
           a.minor_person_id                                  AS person_id,
           b.name,
           a.score,
           a.is_valid,
           a.suspect_status,
           a.last_update_by,
           a.last_update_time,
           b.birth_day,
           b.birth_place,
           b.id_number,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = b.gender_id))       AS gender,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = b.marry_status_id)) AS marry_status,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = b.ethnicity_id))    AS ethnicity,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = b.nationality_id))  AS nationality,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = b.carrer_id))       AS carrer
    FROM (empi.suspect a
             JOIN empi.best_record b ON (((a.major_euid)::text = (b.euid)::text)))
    UNION ALL
    SELECT a.id,
           ''::text                                           AS group_by,
           a.minor_euid                                       AS euid,
           a.major_euid                                       AS minor_euid,
           a.major_person_id                                  AS person_id,
           c.name,
           a.score,
           a.is_valid,
           a.suspect_status,
           a.last_update_by,
           a.last_update_time,
           c.birth_day,
           c.birth_place,
           c.id_number,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = c.gender_id))       AS gender,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = c.marry_status_id)) AS marry_status,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = c.ethnicity_id))    AS ethnicity,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = c.nationality_id))  AS nationality,
           (SELECT code_value_detail.value
            FROM empi.code_value_detail
            WHERE (code_value_detail.id = c.carrer_id))       AS carrer
    FROM (empi.suspect a
             JOIN empi.person c ON ((a.minor_person_id = c.id)));

alter table v_suspect_best_record_person
    owner to postgres;

