create function soda_count(clom character varying, _sch text, _table text, _type text, flag integer) returns integer
    language plpgsql
as
$$
declare
  count1 int;
begin
  if flag = 1 then
        if _type ='in2' or _type ='int4' then
            execute 'select count(1) from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null ;'
        into count1;
          else
           execute 'select count(1) from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null '||'and '||'trim('||clom||') <> '||''''''
        into count1;
        end if;
  execute 'select count(1) from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null ;'
    into count1;
  elseif flag=3 then
      if _type ='in2' or _type ='int4' then
        execute 'select count(1) from ( select distinct patient_id from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null )a;'
        into count1;
      else
        execute 'select count(1) from ( select distinct patient_id from '||_sch||'.'||_table||' where '||clom||' is '||' not '||' null '||'and '||'trim('||clom||') <> '||''''''||' ) a;'
        into count1;
      end if;
  end if ;
  return count1;
end;
$$;

alter function soda_count(varchar, text, text, text, integer) owner to postgres;

