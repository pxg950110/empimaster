create function patient_insert_or_update_patient_master_info() returns trigger
    language plpgsql
as
$$
    -- 创建者 宋力力
---visit域下面就诊总表发生改变search域下面的就诊总表相应的发生改变（插入、删除）
declare
begin
   case TG_OP
     when 'INSERT' then
     insert into search.patient_master_info(patient_id,sex_code,birth_date) VALUES
     ( new.patient_id,new.sex_code,new.birth_date);
    when 'UPDATE' then
    update search.patient_master_info set patient_id=new.patient_id,sex_code=new.sex_code,birth_date=new.birth_date where patient_id=new.patient_id;
     when 'DELETE' then
    delete from search.patient_master_info where   patient_id=old.patient_id ;
    else
    return NULL;
    end case;
return NULL;
end;
$$;

alter function patient_insert_or_update_patient_master_info() owner to postgres;

