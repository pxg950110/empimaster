create function get_outpatient_regid(sd_org_code character varying, sd_soucre_app character varying, sd_source_reg_id character varying, sd_patient_no character varying, OUT out_reg_id integer, OUT out_patient_id integer) returns record
    language plpgsql
as
$$
    -- Author:		ouyang.feng
-- Create date: 2018-6-2
-- Description:	查找门诊病人的基本信息
--
DECLARE  _reg_id INTEGER;---挂号id
declare  _patient_id INTEGER;---病人ID
DECLARE  v_rec_record record;
BEGIN

  SELECT  _reg_id=reg_id,_patient_id=patient_id from visit.outpatient_record
       where source_app=sd_soucre_app
           and org_code=sd_org_code
           and source_reg_id=sd_source_reg_id;

  IF _patient_id ISNULL THEN

      SELECT  _patient_id=patient_id from patient.patient_base_info
         WHERE source_patient_no=sd_patient_no
              and org_code=sd_org_code
                and source_app=sd_soucre_app;
    END IF ;

  IF _reg_id ISNULL  THEN
     SELECT _reg_id=0;
  END IF;

  IF _patient_id ISNULL  THEN
     SELECT _patient_id=0;
  END IF;


  SELECT out_patient_id,out_reg_id;


END;
$$;

alter function get_outpatient_regid(varchar, varchar, varchar, varchar, out integer, out integer) owner to postgres;

