create function get_cf_text_drug_all_id(drgid text) returns text
    language sql
as
$$
SELECT get_cf_drug_all_id(drgid)::text;
$$;

alter function get_cf_text_drug_all_id(text) owner to postgres;

