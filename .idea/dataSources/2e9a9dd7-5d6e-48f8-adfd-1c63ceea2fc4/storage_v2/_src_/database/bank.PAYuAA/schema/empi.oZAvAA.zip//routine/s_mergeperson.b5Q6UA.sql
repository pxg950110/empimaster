create function s_mergeperson(masterpara character varying, minorpara character varying, mergetype character varying)
    returns TABLE(code character varying, msg character varying)
    language plpgsql
as
$$
declare
    sql text;
    MasterEUID varchar(20);
    MinorEUID varchar(20);
    MinorPersonId int;
    Resultcount int;
    curs_euid refcursor;
    rec_person record;
  varnumber int;
BEGIN
  DROP TABLE IF EXISTS temp_personid;
  CREATE TEMPORARY TABLE temp_personid(id int4,euid varchar(20)) ON COMMIT PRESERVE ROWS;
  if (MergeType = '1') then
    begin
      MasterEUID := Masterpara;
      MinorEUID := Minorpara;
      select count(*) into Resultcount from empi.person where euid = Masterpara;
      if (Resultcount > 0) then
        begin
          update empi.person set euid = MasterEUID, operate_type = 5 where euid = MinorEUID;
          update empi.best_record set operate_type = 5 where euid = MinorEUID;
          insert  into empi.link ( major_euid, major_person_id, minor_euid, minor_person_id, operate_type, create_by, create_time)
            values (MasterEUID,null ,MinorEUID,null ,5,null ,current_timestamp);
          return query select 'T'::varchar(2) as code ,'成功'::varchar(20) as msg;
        end;
        else
         return query select 'F'::varchar(2) as code ,'患者不存在'::varchar(20) as msg;
      end if;
      raise  notice  '%',MergeType;
    end;
  elseif (MergeType = '2') then
    begin
       select count(*) into Resultcount from empi.person where euid = Masterpara;
        if (Resultcount <= 0) then
          return query select 'F'::varchar(2) as code ,'患者不存在'::varchar(20) as msg;
        end if;
      insert into temp_personid select id,euid from empi.person where euid in (
        select distinct (euid) from empi.person where id = (select person_id from empi.person_identifier where identifier = Minorpara and is_primary = 1)
      );
      if  not FOUND then
        return query select 'F'::varchar(2) as code ,'Minor患者不存在'::varchar(20) as msg;
      end if;
      select count(*) into Resultcount from temp_personid;
      if  Resultcount = 1 then
        begin
          select id, euid   into  MinorPersonId,MinorEUID from temp_personid;
          update empi.person set euid = MasterEUID,operate_type = 10 where id = MinorPersonId;
          update empi.best_record set operate_type = 10 where euid = MinorEUID;
          insert into empi.link ( major_euid, major_person_id, minor_euid, minor_person_id, operate_type, create_by, create_time)
          values (MasterEUID,null,MinorEUID,MinorPersonId,10,null,current_timestamp);
          return query select 'T'::varchar(2) as code ,'成功'::varchar(20) as msg;
        end;
        else
        begin
        open curs_euid FOR select id,euid from temp_personid ;
          LOOP
            fetch curs_euid into rec_person;
            if FOUND then
              update empi.person set euid = MasterEUID, operate_type = 10 where id = rec_person.id;
              insert into empi.link( major_euid, major_person_id, minor_euid, minor_person_id, operate_type, create_by, create_time) values (
                MasterEUID,null,rec_person.euid, rec_person.id, 10, null, current_timestamp);
               else
              exit ;
            end if;

          end loop;
          close curs_euid;
        end;

      end if;
    end;
  elseif (MergeType = '3') then
      begin
        select euid into MasterEUID from empi.person where id = (select person_id from empi.person_identifier where identifier = Masterpara and is_primary = 1);
        if not FOUND then
          return query select 'F'::varchar(2) as code ,'患者不存在'::varchar(20) as msg;
        end if;
        insert into temp_personid select id,euid from empi.person where euid in (
          select distinct  euid from empi.person where id = (select person_id from empi.person_identifier where identifier = Minorpara and is_primary = 1));
         if not FOUND then
          return query select 'F'::varchar(2) as code ,'Minor患者不存在'::varchar(20) as msg;
        end if;
        select count(*) into Resultcount from temp_personid;
        if  Resultcount = 1 then
          select id,euid into MinorPersonId, MinorEUID from temp_personid;
          update empi.person set euid = MasterEUID,operate_type = 10 where id = MinorPersonId;
          update empi.best_record set operate_type = 10 where euid = MinorEUID;
          insert into empi.link( major_euid, major_person_id, minor_euid, minor_person_id, operate_type, create_by, create_time)
            values (MasterEUID,null,MinorEUID,MinorPersonId,10,null,current_timestamp);
          if  not FOUND then
             return query select 'F'::varchar(2) as code ,'Minor患者不存在'::varchar(20) as msg;
          end if;
          else
          begin
          open curs_euid FOR select id,euid from temp_personid ;
          LOOP
            fetch curs_euid into rec_person;
            if FOUND then
              raise notice '%  %',MasterEUID,rec_person.id;
              update empi.person set euid = MasterEUID, operate_type = 10 where id = rec_person.id;
              insert into empi.link( major_euid, major_person_id, minor_euid, minor_person_id, operate_type, create_by, create_time) values (
                MasterEUID,null,rec_person.euid, rec_person.id, 10, null, current_timestamp);
              else
              exit ;
            end if;
          end loop;
          close curs_euid;
        end;
        end if;

      end;
    end if;
  return query select 'T'::varchar(2) as code ,'合并成功'::varchar(20) as msg;
  EXCEPTION
    WHEN OTHERS THEN -- trap all other error
      raise  info 'error name:%',SQLERRM;
      raise info   'Error State: %', SQLSTATE; -- raise error by name
END;
$$;

alter function s_mergeperson(varchar, varchar, varchar) owner to postgres;

