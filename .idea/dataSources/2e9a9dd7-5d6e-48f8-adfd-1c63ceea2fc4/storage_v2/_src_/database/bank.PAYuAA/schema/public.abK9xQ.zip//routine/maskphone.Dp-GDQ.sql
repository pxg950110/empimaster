create function maskphone(name text) returns text
    language sql
as
$$
SELECT  overlay(name placing '****' from 3 FOR 6 )

$$;

alter function maskphone(text) owner to postgres;

