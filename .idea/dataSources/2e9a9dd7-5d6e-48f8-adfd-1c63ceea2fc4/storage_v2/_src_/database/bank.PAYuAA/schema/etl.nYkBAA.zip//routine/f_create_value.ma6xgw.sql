create function f_create_value(i_item_type character varying, i_value character varying, i_code_sys_id character varying, i_hospitalnu character varying, i_table_name character varying, i_cloumn_name character varying, i_key character varying) returns character varying
    language plpgsql
as
$$
/*********************************************************
*函数名 ： f_create_value
*函数功能描述 ： 用于新华千天项目，根据控件生成目标业务数据
*函数参数 ： 控件类型（控件类型代码）,控件值,控件使用的代码系统,标记唯一记录的值（如住院号）,来源表名,缺失日期的时间字段引用字段名称,标记唯一记录的字段名称
*函数返回值 ：crf_integration_data_detail表中的value值
*作者 ：邓雪聪
*函数创建日期 ： 2018年04月25日
*函数修改日期 ：
*修改人 ：
*修改原因 ：
*版本 ：
*历史版本 ：
*********************************************************/
declare
  v_code_sys_id int;
  v_value varchar(50);
  v_sql   varchar(5000);
  item_value   varchar(5000);
begin
  if i_value is not null and i_value<>'' then
  if i_code_sys_id is not null and i_code_sys_id<>'' then
  v_code_sys_id:=i_code_sys_id::int;
  end if ;
  v_sql:='select ''' || i_value || ''';';
  execute v_sql
  into v_value;
  if v_value~'.0$'
  then
    v_value = replace(v_value, '.0', '');
  end if;
  if i_item_type='1' or i_item_type='10' then
    item_value=array_to_json(array_agg(to_json(v_value::varchar) ));
    elseif i_item_type='3' then
    select array_to_json(array_agg(row_to_json(t1)))::varchar into item_value from (select code_id as id,name as value from mdm.code_set where code_sys_id=v_code_sys_id and code=v_value)t1;
--    select array_to_json(array_agg(row_to_json(t1)))::varchar into item_value from (select code_id::varchar as id,null::int as value from mdm.code_set where code_sys_id=v_code_sys_id and code=v_value)t1;
    elseif i_item_type='6' then
    select cast(json_build_array(array_agg(row_to_json(t2))) as varchar) into item_value from (
    select code_id id from mdm.code_set where code in( select unnest(string_to_array(v_value,','))) and code_sys_id=v_code_sys_id)t2;
    elseif i_item_type='7' then
      if v_value~'；|;|：|!|`|#' then
        v_value:=regexp_replace(v_value,'[；]|[;]|[：]',':','g');
        v_value:=regexp_replace(v_value,'[!]|[`]|[#]','','g');
      end if;
      if  length(v_value)>=19 then
      select array_to_json(array_agg(row_to_json(t3)))::varchar into item_value from (select v_value::date as value,v_value::timestamp as sourcevalue)t3;
    elseif length(v_value)=5 and v_value~':' then
      v_sql:='select array_to_json(array_agg(row_to_json(t3)))::varchar from (select '||i_cloumn_name||'::date as value,case when '||i_cloumn_name||' is not null then concat(('||i_cloumn_name||'::date):: varchar,'' '','''||v_value||''','':00'')::timestamp else concat((''1900-01-01 00:00:00''::date):: varchar,'' '','''||v_value||''','':00'')::timestamp end as sourcevalue from '||i_table_name||' where '||i_key||' ='''||i_hospitalnu||''')t3;';
      execute v_sql into item_value;
    elseif length(v_value)=8 and v_value~':' then
      v_sql:='select array_to_json(array_agg(row_to_json(t3)))::varchar from (select '||i_cloumn_name||'::date as value,case when '||i_cloumn_name||' is not null then concat(('||i_cloumn_name||'::date):: varchar,'' '','''||v_value||''')::timestamp else concat((''1900-01-01 00:00:00''::date):: varchar,'' '','''||v_value||''')::timestamp end as sourcevalue from '||i_table_name||' where '||i_key||' ='''||i_hospitalnu||''')t3;';
      execute v_sql into item_value;
    elseif length(v_value)=4 and position(':' in replace(v_value,'：',':'))=2 then
      v_value:=concat('0',replace(v_value,'：',':'));
      v_sql:='select array_to_json(array_agg(row_to_json(t3)))::varchar from (select '||i_cloumn_name||'::date as value,case when '||i_cloumn_name||' is not null then concat(('||i_cloumn_name||'::date):: varchar,'' '','''||v_value||''','':00'')::timestamp  else concat((''1900-01-01 00:00:00''::date):: varchar,'' '','''||v_value||''','':00'')::timestamp end as sourcevalue from '||i_table_name||' where '||i_key||' ='''||i_hospitalnu||''')t3;';
      execute v_sql into item_value;
    end if;
      item_value:=replace(item_value,'sourcevalue','sourcevalue');
    --item_value:=concat(substring(item_value,1,10),' ',substring(item_value,11,13),' ',substring(item_value,24,7),'v',substring(item_value,32,6),' ',substring(item_value,38,20),'z',substring(item_value,58,3));
    elseif i_item_type='8' then
    select array_to_json(array_agg(row_to_json(t5)))::varchar into item_value from (select code_id as units,v_value as number from mdm.code_set where code_sys_id=v_code_sys_id)t5;
    elseif i_item_type='9' then
    select json_build_array(array_agg(to_json(code_id) ))::varchar into item_value from mdm.code_set where code_sys_id=v_code_sys_id and code in( select unnest(string_to_array(v_value,',')));
    elseif i_item_type='18' then
    select array_to_json(array_agg(to_json(code_id) ))::varchar into item_value from mdm.code_set where code_sys_id=v_code_sys_id and code in( select unnest(string_to_array(v_value,',')));
--    elseif i_item_type='16' then
--    select row_to_json(t4)::varchar into item_value from(select code_sys_id as firstid,code_id as secongid from mdm.code_set where code=v_value and code_sys_id=v_code_sys_id)t4;
  end if;
  end if;
  return item_value;
end;
$$;

alter function f_create_value(varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

