create function two_token(inputs text) returns bytea[]
    immutable
    parallel safe
    language plpgsql
as
$$
DECLARE
  len INT := length($1);
  res    TEXT [] := '{}' :: TEXT [];
  tokens BYTEA [];
BEGIN
    IF len <= 1
    THEN
      res := array_append(res, $1);
    ELSE
      FOR i IN 1..len - 1 LOOP
        res := array_append(res, substring($1, i, 2));
      END LOOP;
    END IF;
  SELECT ARRAY(SELECT md5(encode(convert_to(r, 'utf-8'), 'hex') :: TEXT ||
                          md5(encode(convert_to(right(r, 1), 'utf-8'), 'base64') :: TEXT) :: TEXT) :: BYTEA
               FROM unnest(res) r)
  INTO tokens;
  RETURN tokens;
END;
$$;

alter function two_token(text) owner to postgres;

