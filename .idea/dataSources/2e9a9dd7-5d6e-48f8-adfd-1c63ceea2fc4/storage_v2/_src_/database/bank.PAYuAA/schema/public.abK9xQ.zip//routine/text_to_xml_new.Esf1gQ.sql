create function text_to_xml_new(data text) returns xml
    language plpgsql
as
$$
DECLARE
    result xml;
  BEGIN
      SELECT text_to_xml(data) into result;
      if result is null then
        data:=(SELECT replace(data,'<;','<'));
        SELECT replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(
replace(data,'<20','小于20'),'：<',':小于'),':>',':大于'),'（<','(小于'),'<<','<'),'"<"','""'),'<=>;',''),'<;','<'),':<',':小于'),'小于/','<'),
          '尿量<','尿量小于')
        ::xml into result;
      END IF;
    RETURN result;
  EXCEPTION WHEN OTHERS THEN
     result=NULL ;
      RETURN result;
  END;
$$;

alter function text_to_xml_new(text) owner to postgres;

